R126.dts是TR3600的dts，其他是这个dts include的相关dts
R126.dts is the DTS file for TR3600; the others are DTS files related to this DTS include.