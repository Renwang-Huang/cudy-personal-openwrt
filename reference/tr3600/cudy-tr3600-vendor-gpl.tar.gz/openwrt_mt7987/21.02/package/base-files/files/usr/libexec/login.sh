#!/bin/sh

[ "$(bdinfo dbg)" == OK ] && exec /bin/ash --login

exec /bin/login
