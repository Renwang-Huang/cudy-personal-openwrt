#!/bin/sh
# dns based ad/abuse domain blocking
# Copyright (c) 2015-2026 Dirk Brenken (dev@brenken.org)
# This is free software, licensed under the GNU General Public License v3.

# (s)hellcheck exceptions
# shellcheck disable=all

# set initial defaults
#
export LC_ALL=C
export PATH="/usr/sbin:/usr/bin:/sbin:/bin"
export GAWK_GNU_MATCHERS=1

adb_enabled="0"
adb_debug="0"
adb_nftforce="0"
adb_nftdevforce=""
adb_nftportforce=""
adb_nftallow="0"
adb_nftmacallow=""
adb_nftdevallow=""
adb_nftblock="0"
adb_nftmacblock=""
adb_nftdevblock=""
adb_nftremote="0"
adb_nftremotetimeout="15"
adb_nftmacremote=""
adb_nftbridge="0"
adb_allowdnsv4="86.54.11.100"
adb_allowdnsv6="2a13:1001::86:54:11:100"
adb_remotednsv4="86.54.11.100"
adb_remotednsv6="2a13:1001::86:54:11:100"
adb_blockdnsv4="86.54.11.13"
adb_blockdnsv6="2a13:1001::86:54:11:13"
adb_bridgednsv4="86.54.11.13"
adb_bridgednsv6="2a13:1001::86:54:11:13"
adb_dnsshift="0"
adb_dnsflush="0"
adb_dnstimeout="30"
adb_safesearch="0"
adb_report="0"
adb_trigger=""
adb_triggerdelay="5"
adb_mail="0"
adb_jail="0"
adb_map="0"
adb_tld="1"
adb_dns=""
adb_dnspid=""
adb_locallist="allowlist blocklist"
adb_basedir="/tmp"
adb_finaldir=""
adb_backupdir="/tmp/adblock-backup"
adb_reportdir="/tmp/adblock-report"
adb_rundir="/var/run/adblock"
adb_pidfile="${adb_rundir}/adblock.pid"
adb_rtfile="${adb_rundir}/adblock.runtime.json"
adb_etaglock="${adb_rundir}/adblock.etag.lock"
adb_allowlist="/etc/adblock/adblock.allowlist"
adb_blocklist="/etc/adblock/adblock.blocklist"
adb_mailservice="/etc/adblock/adblock.mail"
adb_dnsfile="adb_list.overall"
adb_feedfile="/etc/adblock/adblock.feeds"
adb_customfeedfile="/etc/adblock/adblock.custom.feeds"
adb_errorlog="/dev/null"
adb_fetchcmd=""
adb_fetchinsecure=""
adb_fetchretry="5"
adb_fetchparm=""
adb_etagparm=""
adb_geoparm=""
adb_geourl="http://ip-api.com/json"
adb_repiface=""
adb_repport="53"
adb_repfilter=""
adb_repchunkcnt="5"
adb_repchunksize="1"
adb_represolve="0"
adb_lookupdomain="localhost"
adb_srtmem="8"
adb_action="${1}"
adb_packages=""
adb_cnt=""

# helper function to find a command in the system and check if it's executable,
# if not try alternative command or log an error if not found
#
f_cmd() {
	local cmd pri_cmd="${1}" sec_cmd="${2}"

	cmd="$(command -v "${pri_cmd}" 2>/dev/null)"
	if [ -z "${cmd}" ]; then
		if [ -n "${sec_cmd}" ]; then
			[ "${sec_cmd}" = "optional" ] && return
			cmd="$(command -v "${sec_cmd}" 2>/dev/null)"
		fi
		if [ -n "${cmd}" ]; then
			printf '%s' "${cmd}"
		else
			f_log "emerg" "command '${pri_cmd:-"-"}'/'${sec_cmd:-"-"}' not found"
		fi
	else
		printf '%s' "${cmd}"
	fi
}

# determine available system memory (MemAvailable) in MB
# mode "float" returns MiB with two decimals, default is integer MiB
#
f_mem() {
	local mem mode="${1}"

	if [ "${mode}" = "float" ]; then
		mem="$("${adb_awkcmd}" '/^MemAvailable/{printf "%.2f", $2/1024}' "/proc/meminfo" 2>>"${adb_errorlog}")"
	else
		mem="$("${adb_awkcmd}" '/^MemAvailable/{printf "%s", int($2/1024)}' "/proc/meminfo" 2>>"${adb_errorlog}")"
	fi
	printf '%s' "${mem:-"0"}"
}

# load adblock environment
#
f_load() {
	local free_mem mem_cores

	# load adblock config and set debug log file
	#
	f_conf
	if [ "${adb_debug}" = "1" ] && [ -d "${adb_basedir}" ]; then
		adb_errorlog="${adb_basedir}/adb_error.log"
	else
		adb_errorlog="/dev/null"
	fi

	# fetch installed packages and system information
	#
	adb_packages="$("${adb_ubuscmd}" -S call rpc-sys packagelist '{ "all": true }' 2>>"${adb_errorlog}")"
	adb_bver="$(printf '%s' "${adb_packages}" | "${adb_jsoncmd}" -ql1 -e '@.packages.adblock')"
	adb_fver="$(printf '%s' "${adb_packages}" | "${adb_jsoncmd}" -ql1 -e '@.packages["luci-app-adblock"]')"
	adb_sysver="$("${adb_ubuscmd}" -S call system board 2>>"${adb_errorlog}" |
		"${adb_jsoncmd}" -ql1 -e '@.model' -e '@.release.target' -e '@.release.distribution' -e '@.release.version' -e '@.release.revision' |
		"${adb_awkcmd}" 'BEGIN{RS="";FS="\n"}{printf "%s, %s, %s %s (%s)",$1,$2,$3,$4,$5}')"

	# detect cpu cores and available memory for memory-aware parallel processing
	# 'mem_cores' is only calculated for auto-detected cores, a manually set 'adb_cores' is never capped
	#
	free_mem="$(f_mem)"
	if [ -z "${adb_cores}" ]; then
		adb_cores="$("${adb_grepcmd}" -cm16 '^processor' /proc/cpuinfo 2>>"${adb_errorlog}")"
		mem_cores="$((${free_mem} / 48))"
		[ "${mem_cores}" -lt "1" ] && mem_cores="1"
	fi
	case "${adb_cores}" in "" | 0 | *[!0-9]*) adb_cores="1" ;; esac
	[ -n "${mem_cores}" ] && [ "${mem_cores}" -lt "${adb_cores}" ] && adb_cores="${mem_cores}"

	# allocate at least 8 MiB of memory per core for sorting
	#
	adb_srtmem="$((${free_mem} / 2 / ${adb_cores}))"
	[ "${adb_srtmem}" -lt "8" ] && adb_srtmem="8"

	# load dns backend and fetch utility
	#
	case "${adb_action}" in
	"report" | "mail" | "dump") ;;
	"search")
		f_dns
		;;
	*)
		f_dns
		f_fetch
		;;
	esac

	# check if reporting is enabled and tcpdump is available,
	# the capture itself runs as separate procd instance 'report'
	#
	if [ "${adb_report}" = "1" ] && [ ! -x "${adb_dumpcmd}" ]; then
		f_log "info" "please install the package 'tcpdump' or 'tcpdump-mini' to use the reporting feature"
	elif [ "${adb_report}" = "0" ] || [ "${adb_action}" = "stop" ]; then
		"${adb_rmcmd}" -f "${adb_reportdir}"/adb_report.pcap* "${adb_reportdir}/adb_report.cfg"
	fi
}

# run the tcpdump capture for reporting
#
f_dump() {
	local port filter cfg

	[ "${adb_report}" != "1" ] || [ ! -x "${adb_dumpcmd}" ] && return 0

	[ ! -d "${adb_reportdir}" ] && [ -d "${adb_reportdir%/*}" ] && mkdir "${adb_reportdir}"
	if [ -z "${adb_repiface}" ]; then
		network_get_device adb_repiface "lan"
		[ -z "${adb_repiface}" ] && network_get_physdev adb_repiface "lan"
		adb_repiface="${adb_repiface:-"any"}"
		uci_set adblock global adb_repiface "${adb_repiface}"
		f_uci "adblock"
	fi
	for port in ${adb_repport}; do
		[ -n "${filter}" ] && filter="${filter} or "
		filter="${filter}(udp port ${port}) or (tcp port ${port})"
	done
	filter="(${filter}) and greater 28"
	[ -n "${adb_repfilter}" ] && filter="${filter} and (${adb_repfilter})"

	if [ -d "${adb_reportdir}" ]; then
		cfg="${adb_repiface}|${adb_repport}|${adb_repfilter}|${adb_repchunksize}|${adb_repchunkcnt}"
		if [ "$("${adb_catcmd}" "${adb_reportdir}/adb_report.cfg" 2>/dev/null)" != "${cfg}" ]; then
			"${adb_rmcmd}" -f "${adb_reportdir}"/adb_report.pcap*
			printf '%s\n' "${cfg}" >"${adb_reportdir}/adb_report.cfg"
		fi
		f_log "info" "tcpdump capture starting for interface: ${adb_repiface}, port: ${adb_repport}, filter: ${adb_repfilter:-"-"}, dir: ${adb_reportdir}"
		exec "${adb_dumpcmd}" --immediate-mode -nn -p -s0 -i "${adb_repiface}" "${filter}" \
			-C "${adb_repchunksize}" -W "${adb_repchunkcnt}" \
			-w "${adb_reportdir}/adb_report.pcap"
	else
		f_log "info" "the reporting directory '${adb_reportdir}' does not exist/is not mounted yet, please set 'adb_reportdir' accordingly"
	fi
}

# check & set environment
#
f_env() {
	: >"${adb_errorlog}"
	read -r adb_starttime _ <"/proc/uptime"
	adb_starttime="${adb_starttime%.*}"
	f_log "info" "adblock instance started ::: action: ${adb_action}, priority: ${adb_nicelimit:-"0"}, pid: ${$}"
	f_jsnup "processing"
	f_extconf
	f_temp
	f_nftadd
	json_init
	if [ -s "${adb_customfeedfile}" ]; then
		if json_load_file "${adb_customfeedfile}" >/dev/null 2>&1; then
			json_get_keys feedlist
			if [ -n "${feedlist}" ]; then
				f_log "info" "adblock custom feed file loaded successfully"
				return
			fi
		fi
	fi
	if [ -s "${adb_feedfile}" ] && json_load_file "${adb_feedfile}" >/dev/null 2>&1; then
		f_log "info" "adblock default feed file loaded successfully"
		return
	else
		f_log "err" "can't load adblock feed file"
	fi
}

# load adblock config
#
f_conf() {
	config_cb() {
		option_cb() {
			local option="${1}" value="${2}"

			case "${option}" in
			*[!a-zA-Z0-9_]*) ;;

			*)
				[ -n "${value}" ] && eval "${option}=\"\${value}\""
				;;
			esac
		}
		list_cb() {
			local append option="${1}" value="${2}"

			case "${option}" in
			*[!a-zA-Z0-9_]*) ;;

			*)
				eval "append=\"\${${option}}\""
				if [ -n "${append}" ]; then
					eval "${option}=\"\${append} \${value}\""
				else
					eval "${option}=\"\${value}\""
				fi
				;;
			esac
		}
	}
	config_load adblock
}

# domain validation
#
f_chkdom() {
	local type prefix column separator

	case "${1}" in
	"feed" | "local" | "allow")
		type="${1}"
		case "${2}" in
		[0-9])
			prefix=""
			column="${2}"
			separator="${3:-[[:space:]]+}"
			;;
		*)
			prefix="${2}"
			column="${3}"
			separator="${4:-[[:space:]]+}"
			;;
		esac
		;;
	"google")
		type="${1}"
		prefix=""
		column="${2}"
		separator="${3:-[[:space:]]+}"
		;;
	esac

	"${adb_awkcmd}" -v type="${type}" -v pre="${prefix}" -v col="${column}" -v chk="${adb_lookupdomain}" -F "${separator}" '
	{
		# check optional search prefix
		if (pre != "" && index($0, pre) != 1) next
		domain = $col
		# remove carriage returns and trim the input
		gsub(/\r|^[[:space:]]+|[[:space:]]+$/, "", domain)
		# add www. for google safe search
		if (type == "google" && domain ~ /^\.+/) { sub(/^\.+/, "", domain); domain = "www." domain }
		# skip empty lines, comments, localhost/loopback (incl. subdomains) and the lookup domain (except in the allowlist)
		if (domain == "" || domain ~ /^(#|(localhost|loopback)(\.|$))/ || (type != "allow" && domain == chk)) next
		# check total length (253 characters)
		len = length(domain)
		if (len > 253) next
		domain = tolower(domain)
		# ASCII + hyphen, no empty label, no leading/trailing hyphen, no trailing dot, TLD starts with a letter
		if (domain !~ /^([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)*[a-z]([a-z0-9-]*[a-z0-9])?$/) next
		# label length 1–63, can only be exceeded by domains longer than 63 characters
		if (len > 63) {
			n = split(domain, L, ".")
			for (i = 1; i <= n; i++) if (length(L[i]) > 63) next
		}
		print domain
	}'

	f_log "debug" "f_chkdom ::: name: ${src_name}, type: ${type}, prefix: ${prefix:-"-"}, column: ${column:-"-"}, separator: ${separator:-"-"}"
}

# load dns backend config
#
f_dns() {
	local dns dns_list dns_section dns_info free_mem dir

	free_mem="$(f_mem)"
	if [ "${adb_action}" = "boot" ] && [ -z "${adb_trigger}" ]; then
		sleep ${adb_triggerdelay:-"5"}
	fi

	if [ -z "${adb_dns}" ]; then
		dns_list="knot-resolver bind-server unbound-daemon smartdns dnsmasq-full dnsmasq-dhcpv6 dnsmasq"
		for dns in ${dns_list}; do
			if printf '%s' "${adb_packages}" | "${adb_jsoncmd}" -ql1 -e "@.packages[\"${dns}\"]" >/dev/null 2>&1; then
				case "${dns}" in
				"knot-resolver")
					dns="kresd"
					;;
				"bind-server")
					dns="named"
					;;
				"unbound-daemon")
					dns="unbound"
					;;
				"dnsmasq-full" | "dnsmasq-dhcpv6")
					dns="dnsmasq"
					;;
				esac

				if command -v "${dns}" >/dev/null 2>&1; then
					adb_dns="${dns}"
					uci_set adblock global adb_dns "${dns}"
					f_uci "adblock"
					break
				fi
			fi
		done
	fi

	if [ "${adb_dns}" != "raw" ] && ! command -v "${adb_dns}" >/dev/null 2>&1; then
		f_log "err" "dns backend not found, please set 'adb_dns' manually"
	fi

	case "${adb_dns}" in
	"dnsmasq")
		adb_dnscachecmd=""
		adb_dnsinstance="${adb_dnsinstance:-"0"}"
		adb_dnsuser="dnsmasq"
		adb_dnsdir="${adb_dnsdir:-""}"
		if [ -z "${adb_dnsdir}" ]; then
			dns_section="$("${adb_ubuscmd}" -S call uci get "{\"config\":\"dhcp\", \"section\":\"@dnsmasq[${adb_dnsinstance}]\", \"type\":\"dnsmasq\"}" 2>>"${adb_errorlog}")"
			dns_info="$(printf '%s' "${dns_section}" | "${adb_jsoncmd}" -l1 -e '@.values["confdir"]')"
			if [ -n "${dns_info}" ]; then
				adb_dnsdir="${dns_info}"
			else
				dns_info="$(printf '%s' "${dns_section}" | "${adb_jsoncmd}" -l1 -e '@.values[".name"]')"
				[ -n "${dns_info}" ] && adb_dnsdir="/tmp/dnsmasq.${dns_info}.d"
			fi
		fi
		adb_dnsheader=""
		adb_dnsdeny="1"
		adb_dnsallow="1"
		adb_dnssafesearch="1"
		adb_dnsstop="address=/#/\nlocal=/#/"
		f_dnsdeny() {
			"${adb_awkcmd}" '
				{
					if (len > 0 && len + length($0) + 1 > 1000) {
						print line
						len = 0
					}
					if (len == 0) {
						line = "local=/" $0 "/"
						len = length(line)
					} else {
						line = line $0 "/"
						len += length($0) + 1
					}
				}
				END { if (len > 0) print line }
			' "${@}"
		}
		f_dnsallow() {
			"${adb_awkcmd}" '{print "local=/"$0"/#"}' "${@}"
		}
		f_dnssafesearch() {
			local item="${1}"

			shift
			"${adb_awkcmd}" -v item="${item}" '{print "address=/"$0"/"item"";print "local=/"$0"/"}' "${@}"
		}
		;;
	"unbound")
		adb_dnscachecmd="$(f_cmd unbound-control optional)"
		adb_dnsinstance=""
		adb_dnsuser="unbound"
		adb_dnsdir="${adb_dnsdir:-"/var/lib/unbound"}"
		adb_dnsheader=""
		adb_dnsdeny="1"
		adb_dnsallow="1"
		adb_dnssafesearch="1"
		adb_dnsstop="local-zone: \".\" always_nxdomain"
		f_dnsdeny() {
			"${adb_awkcmd}" '{print "local-zone: \042"$0"\042 always_nxdomain"}' "${@}"
		}
		f_dnsallow() {
			"${adb_awkcmd}" '{print "local-zone: \042"$0"\042 always_transparent"}' "${@}"
		}
		f_dnssafesearch() {
			local item="${1}"

			shift
			"${adb_awkcmd}" -v item="${item}" \
				'{type="AAAA";if(match(item,/^([0-9]{1,3}\.){3}[0-9]{1,3}$/)){type="A"}}{print "local-data: \042"$0" "type" "item"\042"}' "${@}"
		}
		;;
	"named")
		adb_dnscachecmd="$(f_cmd rndc optional)"
		adb_dnsinstance=""
		adb_dnsuser="bind"
		adb_dnsdir="${adb_dnsdir:-"/var/lib/bind"}"
		adb_dnsheader="\$TTL 2h\n@ IN SOA localhost. root.localhost. (1 6h 1h 1w 2h)\n  IN NS  localhost.\n"
		adb_dnsdeny="1"
		adb_dnsallow="1"
		adb_dnssafesearch="1"
		adb_dnsstop="* CNAME ."
		f_dnsdeny() {
			"${adb_awkcmd}" '{print ""$0" CNAME .\n*."$0" CNAME ."}' "${@}"
		}
		f_dnsallow() {
			"${adb_awkcmd}" '{print ""$0" CNAME rpz-passthru.\n*."$0" CNAME rpz-passthru."}' "${@}"
		}
		f_dnssafesearch() {
			local item="${1}"

			shift
			"${adb_awkcmd}" -v item="${item}" '{print ""$0" CNAME "item".\n*."$0" CNAME "item"."}' "${@}"
		}
		;;
	"kresd")
		adb_dnscachecmd=""
		adb_dnsinstance=""
		adb_dnsuser="root"
		adb_dnsdir="${adb_dnsdir:-"/tmp/kresd"}"
		adb_dnsheader="\$TTL 2h\n@ IN SOA localhost. root.localhost. (1 6h 1h 1w 2h)\n"
		adb_dnsdeny="1"
		adb_dnsallow="1"
		adb_dnssafesearch="1"
		adb_dnsstop="* CNAME ."
		f_dnsdeny() {
			"${adb_awkcmd}" '{print ""$0" CNAME .\n*."$0" CNAME ."}' "${@}"
		}
		f_dnsallow() {
			"${adb_awkcmd}" '{print ""$0" CNAME rpz-passthru.\n*."$0" CNAME rpz-passthru."}' "${@}"
		}
		f_dnssafesearch() {
			local item="${1}"

			shift
			"${adb_awkcmd}" -v item="${item}" '{print ""$0" CNAME "item".\n*."$0" CNAME "item"."}' "${@}"
		}
		;;
	"smartdns")
		adb_dnscachecmd=""
		adb_dnsinstance="${adb_dnsinstance:-"0"}"
		adb_dnsuser="root"
		adb_dnsdir="${adb_dnsdir:-"/tmp/smartdns"}"
		adb_dnsheader=""
		adb_dnsdeny="1"
		adb_dnsallow="1"
		adb_dnssafesearch="1"
		adb_dnsstop="address #"
		f_dnsdeny() {
			"${adb_awkcmd}" '{print "address /"$0"/#"}' "${@}"
		}
		f_dnsallow() {
			"${adb_awkcmd}" '{print "address /"$0"/-"}' "${@}"
		}
		f_dnssafesearch() {
			local item="${1}"

			shift
			"${adb_awkcmd}" -v item="${item}" '{print "cname /"$0"/"item""}' "${@}"
		}
		;;
	"raw")
		adb_dnscachecmd=""
		adb_dnsinstance=""
		adb_dnsuser="root"
		adb_dnsdir="${adb_dnsdir:-"/tmp"}"
		adb_dnsheader=""
		adb_dnsdeny=""
		adb_dnsallow=""
		adb_dnssafesearch=""
		adb_dnsstop=""
		;;
	esac

	# determine final dns file directory based on dns shifting
	#
	if [ "${adb_dnsshift}" = "0" ] || [ -z "${adb_backupdir}" ]; then
		adb_finaldir="${adb_dnsdir}"
		[ -L "${adb_dnsdir}/${adb_dnsfile}" ] && "${adb_rmcmd}" -f "${adb_dnsdir}/${adb_dnsfile}"
	else
		adb_finaldir="${adb_backupdir}"
	fi

	# create dns file with header if it doesn't exist or dns flushing is enabled, also create backup and final directories if they don't exist
	#
	if [ "${adb_action}" != "stop" ]; then
		for dir in "${adb_dnsdir:-"/tmp"}" "${adb_backupdir:-"/tmp"}"; do
			[ ! -d "${dir}" ] && mkdir -p "${dir}"
		done
		if [ "${adb_action}" != "search" ] && [ "${adb_action}" != "report" ] &&
			[ "${adb_action}" != "suspend" ] && [ "${adb_action}" != "resume" ]; then
			if [ "${adb_dnsflush}" = "1" ] || [ "${free_mem:-"0"}" -lt "64" ]; then
				printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
				f_dnsup
			elif [ ! -f "${adb_finaldir}/${adb_dnsfile}" ]; then
				printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
			fi
		fi
	fi

	# check if adblock is enabled
	#
	if [ "${adb_enabled}" = "0" ]; then
		f_extconf
		f_temp
		f_nftremove
		f_rmdns
		f_jsnup "disabled"
		f_log "info" "adblock is currently disabled, please set the config option 'adb_enabled' to '1' to use this service"
		exit 0
	fi

	f_log "debug" "f_dns    ::: dns: ${adb_dns}, dns_instance: ${adb_dnsinstance:-"-"}, dns_user: ${adb_dnsuser}, dns_dir: ${adb_dnsdir}, backup_dir: ${adb_backupdir}, final_dir: ${adb_finaldir}"
}

# load fetch utility
#
f_fetch() {
	local fetch fetch_list insecure update="0"

	# check if the configured fetch utility is available and has SSL support,
	# if not try to find an alternative with SSL support or log an error if not found
	#
	adb_fetchcmd="$(command -v "${adb_fetchcmd}" 2>/dev/null)"
	if [ -z "${adb_fetchcmd}" ]; then
		fetch_list="curl wget-ssl libustream-openssl libustream-wolfssl libustream-mbedtls"
		for fetch in ${fetch_list}; do
			case "${adb_packages}" in *"\"${fetch}\""*)
				case "${fetch}" in
				"wget-ssl")
					fetch="wget"
					;;
				"libustream-openssl" | "libustream-wolfssl" | "libustream-mbedtls")
					fetch="uclient-fetch"
					;;
				esac
				adb_fetchcmd="$(command -v "${fetch}" 2>/dev/null)"
				if [ -n "${adb_fetchcmd}" ]; then
					update="1"
					uci_set adblock global adb_fetchcmd "${fetch}"
					f_uci "adblock"
					break
				fi
				;;
			esac
		done
	fi
	[ -z "${adb_fetchcmd}" ] && f_log "err" "download utility with SSL support not found, please set 'adb_fetchcmd' manually"

	# check the fetch retry value
	#
	case "${adb_fetchretry}" in
	0* | *[!0-9]*)
		adb_fetchretry="5"
		;;
	esac

	# set fetch parameters based on the fetch utility and check if insecure fetching is enabled
	#
	case "${adb_fetchcmd##*/}" in
	"curl")
		[ "${adb_fetchinsecure}" = "1" ] && insecure="--insecure"
		adb_fetchparm="${adb_fetchparm:-"${insecure} --connect-timeout 20 --speed-time 20 --retry-delay 10 --retry $((adb_fetchretry - 1)) --retry-all-errors --fail --silent --globoff --show-error --location -o"}"
		adb_etagparm="${insecure} --connect-timeout 5 --max-time 10 --fail --silent --globoff --location --head"
		adb_geoparm="${insecure} --connect-timeout 5 --max-time 10 --fail --silent --globoff --show-error --location"
		;;
	"wget")
		[ "${adb_fetchinsecure}" = "1" ] && insecure="--no-check-certificate"
		adb_fetchparm="${adb_fetchparm:-"${insecure} --no-cache --no-cookies --timeout=20 --waitretry=10 --tries=${adb_fetchretry} --retry-connrefused -O"}"
		adb_etagparm="${insecure} --tries=1 --timeout=5 --spider --server-response"
		adb_geoparm="${insecure} --tries=1 --timeout=5 --quiet -O-"
		;;
	"uclient-fetch")
		[ "${adb_fetchinsecure}" = "1" ] && insecure="--no-check-certificate"
		adb_fetchparm="${adb_fetchparm:-"${insecure} --timeout=20 -O"}"
		adb_geoparm="${insecure} --timeout=5 --quiet -O-"
		;;
	esac

	f_log "debug" "f_fetch  ::: update: ${update}, cmd: ${adb_fetchcmd:-"-"}, parm: ${adb_fetchparm:-"-"}, etag_parm: ${adb_etagparm:-"-"}, geo_parm: ${adb_geoparm:-"-"}"
}

# create temporary files, directories and set dependent options
#
f_temp() {
	if [ -d "${adb_basedir}" ]; then
		adb_tmpdir="$(mktemp -p "${adb_basedir}" -d)"
		adb_tmpload="$(mktemp -p "${adb_tmpdir}" -tu)"
		adb_tmpfile="$(mktemp -p "${adb_tmpdir}" -tu)"
		adb_srtopts="--temporary-directory=${adb_tmpdir} --compress-program=gzip --parallel=${adb_cores} --buffer-size=${adb_srtmem:-"8"}M"
	else
		f_log "err" "the base directory '${adb_basedir}' does not exist/is not mounted yet, please create the directory or raise the 'adb_triggerdelay' to defer the adblock start"
	fi
	[ ! -s "${adb_pidfile}" ] && printf '%s' "${$}" >"${adb_pidfile}"
}

# remove temporary files and directories
#
f_rmtemp() {
	[ -f "${adb_errorlog}" ] && [ ! -s "${adb_errorlog}" ] && "${adb_rmcmd}" -f "${adb_errorlog}"
	[ -d "${adb_tmpdir}" ] && "${adb_rmcmd}" -rf "${adb_tmpdir}"
	: >"${adb_pidfile}"
}

# remove dns related files
#
f_rmdns() {
	if [ -n "${adb_finaldir}" ]; then
		printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
		f_dnsup
	fi
	f_rmtemp
	if [ -d "${adb_backupdir}" ] && { [ "${adb_action}" = "stop" ] || [ "${adb_enabled}" = "0" ]; }; then
		"${adb_findcmd}" "${adb_backupdir}" -maxdepth 1 -type f -name '*.gz' -exec "${adb_rmcmd}" -f {} +
	fi
}

# commit uci changes
#
f_uci() {
	local config="${1}"

	if [ -n "$(uci -q changes "${config}")" ]; then
		uci_commit "${config}"
		if [ "${config}" = "resolver" ]; then
			printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
			adb_cnt="0"
			f_jsnup "processing"
			"/etc/init.d/${adb_dns}" reload >/dev/null 2>&1
		fi
	fi
}

# get list counter
#
f_count() {
	local files mode="${1}" file="${2}" var="${3}"

	adb_cnt="0"
	if [ -s "${file}" ]; then
		if [ -n "${var}" ] || [ "${mode}" != "final" ]; then
			adb_cnt="$("${adb_awkcmd}" 'END{print NR}' "${file}")"
			[ -n "${var}" ] && printf '%s' "${adb_cnt}"
		else
			# build argument list: main file first, then all subtraction files
			#
			files="${file}"
			[ -s "${adb_tmpdir}/tmp.add.allowlist" ] && files="${files} ${adb_tmpdir}/tmp.add.allowlist"
			for file in "${adb_tmpdir}/tmp.safesearch".*; do
				[ -s "${file}" ] && files="${files} ${file}"
			done
			adb_cnt="$("${adb_awkcmd}" -v hdr="${adb_dnsheader}" -v dns="${adb_dns}" '
				NR == FNR { main += (dns == "dnsmasq" ? split($0, seg, "/") - 2 : 1); next }
				{ sub_cnt++ }
				END {
					cnt = main - sub_cnt
					if (hdr != "") {
						hlines = gsub(/\n/, "", hdr)
						cnt = int((cnt - hlines) / 2)
					}
					if (cnt < 0) cnt = 0
					res = ""
					pos = 0
					s = sprintf("%d", cnt)
					for (i = length(s); i > 0; i--) {
						res = substr(s, i, 1) res
						if (++pos == 3 && i > 1) { res = " " res; pos = 0 }
					}
					print res
				}
			' ${files})"
		fi
	fi
}

# set external config options
#
f_extconf() {
	local config

	case "${adb_dns}" in
	"dnsmasq")
		config="dhcp"
		if [ "${adb_dnsshift}" = "1" ] &&
			! uci_get ${config} @dnsmasq[${adb_dnsinstance}] addnmount | "${adb_grepcmd}" -q "${adb_backupdir}"; then
			uci -q add_list ${config}.@dnsmasq[${adb_dnsinstance}].addnmount="${adb_backupdir}"
		elif [ "${adb_dnsshift}" = "0" ] &&
			uci_get ${config} @dnsmasq[${adb_dnsinstance}] addnmount | "${adb_grepcmd}" -q "${adb_backupdir}"; then
			uci -q del_list ${config}.@dnsmasq[${adb_dnsinstance}].addnmount="${adb_backupdir}"
		fi
		;;
	"kresd")
		config="resolver"
		if [ "${adb_enabled}" = "1" ] &&
			! uci_get ${config} kresd rpz_file | "${adb_grepcmd}" -q "${adb_dnsdir}/${adb_dnsfile}"; then
			uci -q add_list ${config}.kresd.rpz_file="${adb_dnsdir}/${adb_dnsfile}"
		elif [ "${adb_enabled}" = "0" ] &&
			uci_get ${config} kresd rpz_file | "${adb_grepcmd}" -q "${adb_dnsdir}/${adb_dnsfile}"; then
			uci -q del_list ${config}.kresd.rpz_file="${adb_dnsdir}/${adb_dnsfile}"
		fi
		;;
	"smartdns")
		config="smartdns"
		if [ "${adb_enabled}" = "1" ] &&
			! uci_get ${config} @${config}[${adb_dnsinstance}] conf_files | "${adb_grepcmd}" -q "${adb_dnsdir}/${adb_dnsfile}"; then
			uci -q add_list ${config}.@${config}[${adb_dnsinstance}].conf_files="${adb_dnsdir}/${adb_dnsfile}"
		elif [ "${adb_enabled}" = "0" ] &&
			uci_get ${config} @${config}[${adb_dnsinstance}] conf_files | "${adb_grepcmd}" -q "${adb_dnsdir}/${adb_dnsfile}"; then
			uci -q del_list ${config}.@${config}[${adb_dnsinstance}].conf_files="${adb_dnsdir}/${adb_dnsfile}"
		fi
		;;
	esac
	f_uci "${config}"
}

# restart dns backend
#
f_dnsup() {
	local restart_rc nft_rc cnt="0" out_rc="4"

	if [ "${adb_dns}" = "raw" ] || [ -z "${adb_dns}" ]; then
		out_rc="0"
	else

		# load external dns bridge
		#
		if { [ -n "${adb_bridgednsv4}" ] || [ -n "${adb_bridgednsv6}" ]; } && [ "${adb_nftbridge}" = "1" ]; then
			if "${adb_nftcmd}" list chain inet adblock dns-bridge >/dev/null 2>&1; then
				if [ -n "${adb_bridgednsv4}" ]; then
					"${adb_nftcmd}" add rule inet adblock dns-bridge meta nfproto ipv4 meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_bridgednsv4}:53 2>>"${adb_errorlog}"
					nft_rc="${?}"
				fi
				if [ -n "${adb_bridgednsv6}" ]; then
					"${adb_nftcmd}" add rule inet adblock dns-bridge meta nfproto ipv6 meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_bridgednsv6}]:53 2>>"${adb_errorlog}"
					nft_rc="$((nft_rc + $?))"
				fi
				if [ "${nft_rc}" = "0" ]; then
					f_log "debug" "external DNS bridge loaded: ${adb_bridgednsv4:-"-"} / ${adb_bridgednsv6:-"-"}"
				else
					f_log "info" "failed to load external DNS bridge: ${adb_bridgednsv4:-"-"} / ${adb_bridgednsv6:-"-"}"
				fi
			fi
		fi

		# restart dns backend
		#
		if [ "${adb_dnsflush}" = "0" ]; then
			case "${adb_dns}" in
			"unbound")
				if [ -x "${adb_dnscachecmd}" ] && [ -d "${adb_tmpdir}" ] && [ -f "${adb_dnsdir}/unbound.conf" ]; then
					"${adb_dnscachecmd}" -c "${adb_dnsdir}/unbound.conf" dump_cache >"${adb_tmpdir}/adb_cache.dump" 2>>"${adb_errorlog}"
				fi
				"/etc/init.d/${adb_dns}" restart >/dev/null 2>&1
				restart_rc="${?}"
				;;
			"named")
				if [ -x "${adb_dnscachecmd}" ] && [ -f "/etc/bind/rndc.conf" ]; then
					"${adb_dnscachecmd}" -c "/etc/bind/rndc.conf" reload >/dev/null 2>&1
					restart_rc="${?}"
				fi
				if [ -z "${restart_rc}" ] || { [ -n "${restart_rc}" ] && [ "${restart_rc}" != "0" ]; }; then
					"/etc/init.d/${adb_dns}" restart >/dev/null 2>&1
					restart_rc="${?}"
				fi
				;;
			*)
				"/etc/init.d/${adb_dns}" restart >/dev/null 2>&1
				restart_rc="${?}"
				;;
			esac
		fi
		if [ -z "${restart_rc}" ]; then
			"/etc/init.d/${adb_dns}" restart >/dev/null 2>&1
			restart_rc="${?}"
		fi
	fi

	# check if dns backend is responsive, restore dns cache for unbound and get dns backend pid
	#
	if [ "${restart_rc}" = "0" ]; then
		while [ "${cnt}" -le "${adb_dnstimeout}" ]; do
			if "${adb_lookupcmd}" "${adb_lookupdomain}." >/dev/null 2>&1; then
				out_rc="0"
				break
			fi
			cnt="$((cnt + 1))"
			sleep 1
		done
		if [ "${out_rc}" = "0" ] && [ "${adb_dns}" = "unbound" ]; then
			if [ -x "${adb_dnscachecmd}" ] && [ -d "${adb_tmpdir}" ] && [ -s "${adb_tmpdir}/adb_cache.dump" ]; then
				"${adb_dnscachecmd}" -c "${adb_dnsdir}/unbound.conf" load_cache <"${adb_tmpdir}/adb_cache.dump" >/dev/null 2>&1
				restart_rc="${?}"
			fi
		fi
	fi

	# remove external dns bridge
	#
	if [ "${adb_nftbridge}" = "1" ] && "${adb_nftcmd}" list chain inet adblock dns-bridge >/dev/null 2>&1; then
		"${adb_nftcmd}" flush chain inet adblock dns-bridge 2>>"${adb_errorlog}"
		nft_rc="${?}"
		if [ "${nft_rc}" = "0" ]; then
			f_log "debug" "external DNS bridge removed"
		else
			f_log "info" "failed to remove external DNS bridge"
		fi
	fi

	f_log "debug" "f_dnsup  ::: dns: ${adb_dns}, cache_cmd: ${adb_dnscachecmd:-"-"}, lookup_domain: ${adb_lookupdomain:-"-"}, restart_rc: ${restart_rc:-"-"}, dns_flush: ${adb_dnsflush}, dns_timeout: ${adb_dnstimeout}, dns_cnt: ${cnt}, nft_rc: ${nft_rc:-"-"}, rc: ${out_rc}"
	return "${out_rc}"
}

# handle etag http header
#
f_etag() {
	local http_head http_code etag_id etag_cnt etag_match out_rc="4" feed="${1}" feed_url="${2}" feed_suffix="${3}" feed_cnt="${4:-"1"}" feed_rm="${5:-"0"}"

	if [ -n "${adb_etagparm}" ]; then

		# ensure etag file exists
		#
		[ ! -f "${adb_backupdir}/adblock.etag" ] && : >"${adb_backupdir}/adblock.etag"

		if [ "${feed_rm}" = "0" ]; then

			# fetch http headers and extract http code and etag/last-modified header
			#
			http_head="$("${adb_fetchcmd}" ${adb_etagparm} "${feed_url}${feed_suffix}" 2>&1)"
			http_code="$(printf '%s' "${http_head}" | "${adb_awkcmd}" 'tolower($0)~/^[[:space:]]*http\/[0123\.]+ /{code=$2} END{printf "%s",code}')"
			etag_id="$(printf '%s' "${http_head}" | "${adb_awkcmd}" 'tolower($0)~/^[[:space:]]*etag: /{gsub(/[\r"]/,"");id=$2} END{printf "%s",id}')"

			# if etag header is not present, try to use last-modified header as fallback for change detection
			#
			if [ -z "${etag_id}" ]; then
				etag_id="$(printf '%s' "${http_head}" | "${adb_awkcmd}" 'tolower($0)~/^[[:space:]]*last-modified: /{gsub(/[Ll]ast-[Mm]odified:|[[:space:]]|,|:/,"");lm=$1} END{printf "%s",lm}')"
			fi

			# if last-modified is also missing, fall back to a positive content-length as change indicator
			#
			if [ -z "${etag_id}" ]; then
				etag_id="$(printf '%s' "${http_head}" | "${adb_awkcmd}" 'tolower($0)~/^[[:space:]]*content-length: /{gsub(/\r/,"");cl=$2} END{if(cl+0>0)printf "%s",cl}')"
			fi
		fi

		# acquire exclusive lock on etag file to serialize concurrent read-modify-write from parallel feeds
		#
		exec 9>"${adb_etaglock}"
		"${adb_flockcmd}" -x 9

		if [ "${feed_rm}" = "0" ]; then

			# compare http code and etag id with stored values, update etag file and return code accordingly
			#
			etag_cnt="$("${adb_awkcmd}" -v f="${feed}" -v s="${feed_suffix}" -v e="${etag_id}" '
			BEGIN { matched = 0; cnt = 0; p = f " " s "\t" }
			$1 == f { cnt++ }
			index($0, p) == 1 {
				rest = substr($0, length(p) + 1)
				if (rest == e) { matched = 1 }
			}
			END { print cnt; exit !matched }' "${adb_backupdir}/adblock.etag")"
			etag_match="${?}"
		fi

		# compare http code, etag count and etag id; update etag file and return code accordingly
		#
		if [ "${feed_rm}" = "sweep" ]; then

			# drop entries for feeds no longer in the active feed list (${feed})
			#
			"${adb_awkcmd}" -v feeds=" ${feed} " 'index(feeds, " " $1 " ")' \
				"${adb_backupdir}/adblock.etag" >"${adb_backupdir}/adblock.etag.new" 2>>"${adb_errorlog}" &&
				"${adb_mvcmd}" -f "${adb_backupdir}/adblock.etag.new" "${adb_backupdir}/adblock.etag"
			out_rc="${?}"
		elif [ "${feed_rm}" = "0" ] && [ "${http_code}" = "200" ] && [ "${etag_cnt}" = "${feed_cnt}" ] && [ -n "${etag_id}" ] && [ "${etag_match}" = "0" ]; then
			out_rc="0"
		elif [ -n "${etag_id}" ] || [ "${feed_rm}" = "1" ]; then

			# if feed count is less than etag count, it means the feed source has been removed or disabled, so remove all entries for this feed,
			# otherwise only remove the entry with the matching feed suffix (feed url) to allow multiple sources for the same feed
			#
			if [ "${feed_rm}" = "1" ] || [ "${feed_cnt}" -lt "${etag_cnt:-"0"}" ]; then
				"${adb_awkcmd}" -v f="${feed}" '$1 != f' \
					"${adb_backupdir}/adblock.etag" >"${adb_backupdir}/adblock.etag.new"
			else
				"${adb_awkcmd}" -v f="${feed}" -v s="${feed_suffix}" '
				BEGIN { p = f " " s "\t" }
				index($0, p) != 1' \
					"${adb_backupdir}/adblock.etag" >"${adb_backupdir}/adblock.etag.new"
			fi &&
				"${adb_mvcmd}" -f "${adb_backupdir}/adblock.etag.new" "${adb_backupdir}/adblock.etag"
			[ "${feed_rm}" = "0" ] && printf '%s\t%s\n' "${feed} ${feed_suffix}" "${etag_id}" >>"${adb_backupdir}/adblock.etag"
			out_rc="2"
		fi

		# release lock
		#
		exec 9>&-
	fi

	f_log "debug" "f_etag   ::: feed: ${feed}, suffix: ${feed_suffix:-"-"}, http_code: ${http_code:-"-"}, feed/etag: ${feed_cnt}/${etag_cnt:-"0"}, rm: ${feed_rm}, rc: ${out_rc}"
	return "${out_rc}"
}

# add adblock-related nft rules
#
f_nftadd() {
	local devices device port file="${adb_tmpdir}/adb_nft.add"

	# only proceed if at least one feature is enabled
	#
	if [ "${adb_nftallow}" = "0" ] && [ "${adb_nftblock}" = "0" ] &&
		[ "${adb_nftremote}" = "0" ] && [ "${adb_nftforce}" = "0" ] &&
		[ "${adb_nftbridge}" = "0" ]; then
		return
	fi

	# remove existing adblock-related nft rules on restart
	#
	[ "${adb_action}" = "restart" ] && f_nftremove

	# do not proceed if adblock-related nft rules already exists
	#
	if "${adb_nftcmd}" -t list table inet adblock >/dev/null 2>&1; then
		return
	fi

	# do not proceed if action is stop/suspend/resume
	#
	if [ "${adb_action}" = "stop" ] || [ "${adb_action}" = "suspend" ] || [ "${adb_action}" = "resume" ]; then
		return
	fi

	# prepare nftables rules for adblock features
	#
	{
		# nft header (tables, sets, base and regular chains)
		#
		printf '%s\n\n' "#!${adb_nftcmd} -f"
		printf '%s\n' "add table inet adblock"

		# allow Set
		#
		if [ "${adb_nftallow}" = "1" ] && [ -n "${adb_nftmacallow}" ]; then
			printf '%s\n' "add set inet adblock mac_allow { type ether_addr; flags interval; auto-merge; elements = { ${adb_nftmacallow// /, } }; }"
		fi

		# remote allow Set with timeout, for MACs that should be temporary allowed to bypass dns blocking
		#
		if [ "${adb_nftremote}" = "1" ] && [ -n "${adb_nftmacremote}" ]; then
			printf '%s\n' "add set inet adblock mac_remote { type ether_addr; flags timeout; timeout ${adb_nftremotetimeout}m; }"
		fi

		# adblock pre-routing chain for allow/block rules
		#
		if [ "${adb_nftblock}" = "1" ] && [ -n "${adb_nftmacblock}" ]; then
			printf '%s\n' "add set inet adblock mac_block { type ether_addr; flags interval; auto-merge; elements = { ${adb_nftmacblock// /, } }; }"
		fi
		printf '%s\n' "add chain inet adblock pre-routing { type nat hook prerouting priority -150; policy accept; }"
		printf '%s\n' "add chain inet adblock _reject"

		# dns-bridge base chain
		#
		printf '%s\n' "add chain inet adblock dns-bridge { type nat hook prerouting priority -160; policy accept; }"

		# reject chain rules
		#
		printf '%s\n' "add rule inet adblock _reject meta l4proto tcp counter reject with tcp reset"
		printf '%s\n' "add rule inet adblock _reject counter reject with icmpx host-unreachable"

		# external allow rules
		#
		if [ "${adb_nftallow}" = "1" ]; then
			if [ -n "${adb_nftmacallow}" ]; then
				[ -n "${adb_allowdnsv4}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv4 ether saddr @mac_allow meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_allowdnsv4}:53"
				[ -n "${adb_allowdnsv6}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv6 ether saddr @mac_allow meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_allowdnsv6}]:53"
			fi
			for device in ${adb_nftdevallow}; do
				[ -n "${adb_allowdnsv4}" ] && printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto ipv4 meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_allowdnsv4}:53"
				[ -n "${adb_allowdnsv6}" ] && printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto ipv6 meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_allowdnsv6}]:53"
			done
			f_log "debug" "adblock-related nft allow rules prepared for external DNS ${adb_allowdnsv4:-"-"} / ${adb_allowdnsv6:-"-"}"
		fi

		# external remote allow rules
		#
		if [ "${adb_nftremote}" = "1" ] && [ -n "${adb_nftmacremote}" ]; then
			[ -n "${adb_remotednsv4}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv4 ether saddr @mac_remote meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_remotednsv4}:53"
			[ -n "${adb_remotednsv6}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv6 ether saddr @mac_remote meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_remotednsv6}]:53"
			f_log "debug" "adblock-related nft remote allow rules prepared for external DNS ${adb_remotednsv4:-"-"} / ${adb_remotednsv6:-"-"} with timeout of ${adb_nftremotetimeout} minutes"
		fi

		# external block rules
		#
		if [ "${adb_nftblock}" = "1" ]; then
			if [ -n "${adb_nftmacblock}" ]; then
				[ -n "${adb_blockdnsv4}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv4 ether saddr @mac_block meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_blockdnsv4}:53"
				[ -n "${adb_blockdnsv6}" ] && printf '%s\n' "add rule inet adblock pre-routing meta nfproto ipv6 ether saddr @mac_block meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_blockdnsv6}]:53"
			fi
			for device in ${adb_nftdevblock}; do
				[ -n "${adb_blockdnsv4}" ] && printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto ipv4 meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_blockdnsv4}:53"
				[ -n "${adb_blockdnsv6}" ] && printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto ipv6 meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_blockdnsv6}]:53"
			done
			f_log "debug" "adblock-related nft block rules prepared for external DNS ${adb_blockdnsv4:-"-"} / ${adb_blockdnsv6:-"-"}"
		fi

		# local dns enforcement
		#
		if [ "${adb_nftforce}" = "1" ]; then

			# device/vlan exceptions
			#
			for device in ${adb_nftdevallow} ${adb_nftdevblock}; do
				case " ${devices} " in
				*" ${device} "*) ;;

				*)
					[ -n "${devices}" ] && devices="${devices} ${device}" || devices="${device}"
					printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" return"
					;;
				esac
			done

			# mac exceptions
			#
			for device in ${adb_nftdevforce}; do
				if [ "${adb_nftallow}" = "1" ] && [ -n "${adb_nftmacallow}" ]; then
					printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" ether saddr @mac_allow return"
				fi
				if [ "${adb_nftblock}" = "1" ] && [ -n "${adb_nftmacblock}" ]; then
					printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" ether saddr @mac_block return"
				fi

				# dns enforce rules
				#
				for port in ${adb_nftportforce}; do
					if [ "${port}" = "53" ]; then
						printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto { ipv4, ipv6 } meta l4proto { udp, tcp } th dport ${port} counter redirect to :${port}"
					else
						printf '%s\n' "add rule inet adblock pre-routing iifname \"${device}\" meta nfproto { ipv4, ipv6 } meta l4proto { udp, tcp } th dport ${port} counter goto _reject"
					fi
				done
			done
			f_log "debug" "adblock-related nft local DNS enforcement rules prepared for devices: ${adb_nftdevforce// /, } and ports: ${adb_nftportforce// /, }"
		fi
	} >"${file}"
	if "${adb_nftcmd}" -f "${file}" 2>>"${adb_errorlog}"; then
		f_log "info" "adblock-related nft rules loaded"
	else
		f_log "err" "failed to load adblock-related nft rules"
	fi
}

# remove adblock-related nft rules
#
f_nftremove() {
	local file="${adb_tmpdir}/adb_nft.remove"

	if "${adb_nftcmd}" -t list table inet adblock >/dev/null 2>&1; then
		{
			printf '%s\n' "#!${adb_nftcmd} -f"
			printf '%s\n' "delete table inet adblock"
		} >"${file}"

		if "${adb_nftcmd}" -f "${file}" 2>>"${adb_errorlog}"; then
			f_log "info" "adblock-related nft rules removed"
		else
			f_log "err" "failed to remove adblock-related nft rules"
		fi
	fi
}

# remove a single feed from the active feed list
#
f_feedrm() {
	adb_feed=" ${adb_feed} "
	adb_feed="${adb_feed// ${1} / }"
	adb_feed="${adb_feed# }"
	adb_feed="${adb_feed% }"
}

# extract and validate the host part of an url
#
f_urlhost() {
	local host="${1#*://}"

	host="${host%%[/?#]*}"
	host="${host##*@}"
	host="${host%:*}"
	printf '%s\n' "${host}" | f_chkdom local 1
}

# backup/restore/remove blocklists
#
f_list() {
	local file files item array safe_url safe_ips safe_cname safe_domains ip out_rc file_name name
	local mode="${1}" src_name="${2:-"${src_name}"}" in_rc="${src_rc:-0}" use_cname="0"

	case "${mode}" in
	"blocklist" | "allowlist")
		src_name="${mode}"
		case "${src_name}" in
		"blocklist")
			if [ -f "${adb_blocklist}" ]; then
				file_name="${adb_tmpfile}.${src_name}"
				f_chkdom local 1 <"${adb_blocklist}" >"${adb_tmpdir}/tmp.raw.${src_name}"
				if [ "${adb_tld}" = "1" ]; then
					if [ -s "${adb_tmpdir}/tmp.rem.allowlist" ]; then
						"${adb_awkcmd}" '
									NR==FNR { member[$1]; next }
									!($1 in member) {
										n = split($1, seg, ".")
										for (f = n; f > 1; f--) printf "%s.", seg[f]
										print seg[1]
									}
								' "${adb_tmpdir}/tmp.rem.allowlist" "${adb_tmpdir}/tmp.raw.${src_name}"
					else
						"${adb_awkcmd}" 'BEGIN{FS="."}NF==2{print $2"."$1;next}NF==3{print $3"."$2"."$1;next}{for(f=NF;f>1;f--)printf "%s.",$f;print $1}' "${adb_tmpdir}/tmp.raw.${src_name}"
					fi | "${adb_sortcmd}" ${adb_srtopts} -u >"${file_name}"
					out_rc="${?}"
				else
					if [ -s "${adb_tmpdir}/tmp.rem.allowlist" ]; then
						"${adb_awkcmd}" 'NR==FNR{member[$1];next}!($1 in member)' "${adb_tmpdir}/tmp.rem.allowlist" "${adb_tmpdir}/tmp.raw.${src_name}" |
							"${adb_sortcmd}" ${adb_srtopts} -u >"${file_name}" 2>>"${adb_errorlog}"
					else
						"${adb_sortcmd}" ${adb_srtopts} -u "${adb_tmpdir}/tmp.raw.${src_name}" 2>>"${adb_errorlog}" >"${file_name}"
					fi
					out_rc="${?}"
				fi
			fi
			;;
		"allowlist")
			if [ -f "${adb_allowlist}" ] && [ "${adb_dnsallow}" = "1" ]; then
				file_name="${adb_tmpdir}/tmp.raw.${src_name}"
				[ "${adb_lookupdomain}" != "localhost" ] && { printf '%s\n' "${adb_lookupdomain}" | f_chkdom allow 1; } >"${file_name}"
				f_chkdom allow 1 <"${adb_allowlist}" >>"${file_name}"
				"${adb_catcmd}" "${file_name}" >"${adb_tmpdir}/tmp.rem.${src_name}"
				f_dnsallow "${file_name}" >"${adb_tmpdir}/tmp.add.${src_name}"
				out_rc="${?}"
				if [ "${adb_jail}" = "1" ] && [ -n "${adb_dnsstop}" ]; then
					printf '%b' "${adb_dnsheader}" >"${adb_tmpdir}/${adb_dnsfile}"
					"${adb_catcmd}" "${adb_tmpdir}/tmp.add.${src_name}" >>"${adb_tmpdir}/${adb_dnsfile}"
					printf '%b\n' "${adb_dnsstop}" >>"${adb_tmpdir}/${adb_dnsfile}"
				fi
			fi
			;;
		esac
		;;
	"safesearch")
		file_name="${adb_tmpdir}/tmp.safesearch.${src_name}"
		case "${adb_dns}" in
		"named" | "kresd" | "smartdns")
			use_cname="1"
			;;
		esac
		case "${src_name}" in
		"google")
			safe_url="https://www.google.com/supported_domains"
			safe_cname="forcesafesearch.google.com"

			# refresh if cache is missing or older than 30 days
			#
			if [ -s "${adb_backupdir}/safesearch.${src_name}.gz" ] &&
				[ -z "$("${adb_findcmd}" "${adb_backupdir}/safesearch.${src_name}.gz" -mtime +30 2>>"${adb_errorlog}")" ]; then
				"${adb_zcatcmd}" "${adb_backupdir}/safesearch.${src_name}.gz" >"${adb_tmpdir}/tmp.load.safesearch.${src_name}"
			else
				"${adb_fetchcmd}" ${adb_fetchparm} "${adb_tmpdir}/tmp.load.safesearch.${src_name}" "${safe_url}" 2>>"${adb_errorlog}"
				if [ -s "${adb_tmpdir}/tmp.load.safesearch.${src_name}" ]; then
					"${adb_gzipcmd}" -cf "${adb_tmpdir}/tmp.load.safesearch.${src_name}" >"${adb_backupdir}/safesearch.${src_name}.gz"
				elif [ -s "${adb_backupdir}/safesearch.${src_name}.gz" ]; then
					"${adb_zcatcmd}" "${adb_backupdir}/safesearch.${src_name}.gz" >"${adb_tmpdir}/tmp.load.safesearch.${src_name}"
				fi
			fi
			[ -s "${adb_tmpdir}/tmp.load.safesearch.${src_name}" ] &&
				safe_domains="$(f_chkdom google 1 <"${adb_tmpdir}/tmp.load.safesearch.${src_name}")"
			;;
		"bing")
			safe_cname="strict.bing.com"
			safe_domains="www.bing.com"
			;;
		"brave")
			safe_cname="forcesafe.search.brave.com"
			safe_domains="search.brave.com"
			;;
		"duckduckgo")
			safe_cname="safe.duckduckgo.com"
			safe_domains="duckduckgo.com"
			;;
		"pixabay")
			safe_cname="safesearch.pixabay.com"
			safe_domains="pixabay.com"
			;;
		"yandex")
			safe_cname="familysearch.yandex.ru"
			safe_domains="ya.ru yandex.ru yandex.com yandex.com.tr yandex.ua yandex.by yandex.ee yandex.lt yandex.lv yandex.md yandex.uz yandex.tm yandex.tj yandex.az yandex.kz"
			;;
		"youtube")
			safe_cname="restrict.youtube.com"
			safe_domains="www.youtube.com m.youtube.com youtubei.googleapis.com youtube.googleapis.com www.youtube-nocookie.com"
			;;
		esac
		if [ -n "${safe_domains}" ] && [ -n "${safe_cname}" ]; then
			if [ "${use_cname}" = "0" ]; then
				safe_ips="$("${adb_lookupcmd}" "${safe_cname}" 2>>"${adb_errorlog}" | "${adb_awkcmd}" '/^Address[ 0-9]*: /{ORS=" ";print $NF}')"
			fi
			if [ -n "${safe_ips}" ] || [ "${use_cname}" = "1" ]; then
				printf '%s\n' ${safe_domains} >"${adb_tmpdir}/tmp.raw.safesearch.${src_name}"
				[ "${use_cname}" = "1" ] && array="${safe_cname}" || array="${safe_ips}"
			fi
		fi
		if [ -s "${adb_tmpdir}/tmp.raw.safesearch.${src_name}" ]; then
			: >"${file_name}"
			for item in ${array}; do
				if ! f_dnssafesearch "${item}" "${adb_tmpdir}/tmp.raw.safesearch.${src_name}" >>"${file_name}"; then
					: >"${file_name}"
					break
				fi
			done
			: >"${adb_tmpdir}/tmp.raw.safesearch.${src_name}"
			out_rc="0"
		fi
		;;
	"prepare")
		file_name="${src_tmpfile}"
		if [ "${src_rc}" = "0" ] && [ -s "${src_tmpload}" ]; then
			if [ "${adb_tld}" = "1" ]; then
				f_chkdom ${src_rset} <"${src_tmpload}" |
					"${adb_awkcmd}" 'BEGIN{FS="."}NF==2{print $2"."$1;next}NF==3{print $3"."$2"."$1;next}{for(f=NF;f>1;f--)printf "%s.",$f;print $1}' |
					"${adb_sortcmd}" ${adb_srtopts} -u >"${src_tmpfile}" 2>>"${adb_errorlog}"
			else
				f_chkdom ${src_rset} <"${src_tmpload}" |
					"${adb_sortcmd}" ${adb_srtopts} -u >"${src_tmpfile}" 2>>"${adb_errorlog}"
			fi
			out_rc="${?}"
			"${adb_rmcmd}" -f "${src_tmpload}"
			if [ "${out_rc}" = "0" ] && [ -s "${src_tmpfile}" ]; then
				f_list backup
			elif [ "${adb_action}" != "boot" ] && [ "${adb_action}" != "start" ]; then
				f_log "info" "preparation of '${src_name}' failed, rc: ${out_rc}"
				[ "${adb_action}" = "reload" ] && f_etag "${src_name}" "" "" "" "1"
				f_list restore
				out_rc="${?}"
				: >"${src_tmpfile}"
			fi
		else
			f_log "info" "download of '${src_name}' failed, url: ${src_url}, rule: ${src_rset:-"-"}, categories: ${src_cat:-"-"}, rc: ${src_rc}"
			if [ "${adb_action}" != "boot" ] && [ "${adb_action}" != "start" ]; then
				[ "${adb_action}" = "reload" ] && f_etag "${src_name}" "" "" "" "1"
				f_list restore
				out_rc="${?}"
			fi
		fi
		"${adb_rmcmd}" -f "${src_tmpload}"
		;;
	"backup")
		file_name="${src_tmpfile}"
		"${adb_rmcmd}" -f "${src_tmprmfile}"
		"${adb_gzipcmd}" -cf "${src_tmpfile}" >"${adb_backupdir}/adb_list.${src_name}.gz"
		out_rc="${?}"
		;;
	"restore")
		file_name="${src_tmpfile}"
		if [ -n "${src_name}" ] && [ -s "${adb_backupdir}/adb_list.${src_name}.gz" ]; then
			"${adb_zcatcmd}" "${adb_backupdir}/adb_list.${src_name}.gz" >"${src_tmpfile}"
			out_rc="${?}"
		elif [ -z "${src_name}" ]; then
			for file in "${adb_backupdir}/adb_list."*.gz; do
				if [ -r "${file}" ]; then
					name="${file##*/}"
					name="${name%.*}"
					"${adb_zcatcmd}" "${file}" >"${adb_tmpfile}.${name}"
					out_rc="${?}"
					[ "${out_rc}" != "0" ] && break
				fi
			done
		else
			out_rc="4"
		fi
		case "${adb_action}" in
		"boot" | "start" | "restart" | "resume") ;;
		*)
			if [ -n "${src_name}" ] && [ "${out_rc}" != "0" ]; then
				printf '%s\n' "${src_name}" >"${src_tmprmfile}"
			fi
			;;
		esac
		;;
	"remove")
		"${adb_rmcmd}" "${adb_backupdir}/adb_list.${src_name}.gz" 2>>"${adb_errorlog}"
		out_rc="${?}"
		f_feedrm "${src_name}"
		;;
	"merge")
		src_name=""
		file_name="${adb_tmpdir}/${adb_dnsfile}"

		# remove stale backup files
		#
		files=""
		for file in ${adb_feed}; do
			files="${files} ! -name adb_list.${file}.gz"
		done
		if [ "${adb_safesearch}" = "1" ] && [ "${adb_dnssafesearch}" = "1" ]; then
			files="${files} ! -name safesearch.google.gz"
		fi
		"${adb_findcmd}" "${adb_backupdir}" -maxdepth 1 -type f -name '*.gz' ${files} -print0 2>>"${adb_errorlog}" | "${adb_xargscmd}" -0r "${adb_rmcmd}" -f

		# merge files
		#
		for file in "${adb_tmpfile}".*; do break; done
		if [ -e "${file}" ]; then
			"${adb_sortcmd}" --temporary-directory="${adb_tmpdir}" --compress-program=gzip --batch-size=64 -mu "${adb_tmpfile}".* 2>>"${adb_errorlog}" >"${file_name}"
			out_rc="${?}"
		else
			: >"${file_name}"
			out_rc="4"
		fi
		"${adb_rmcmd}" -f "${adb_tmpfile}".*
		;;
	"final")
		src_name=""
		file_name="${adb_finaldir}/${adb_dnsfile}"
		[ -s "${adb_tmpdir}/tmp.add.allowlist" ] &&
			"${adb_sortcmd}" ${adb_srtopts} -u "${adb_tmpdir}/tmp.add.allowlist" -o "${adb_tmpdir}/tmp.add.allowlist"
		{
			[ -n "${adb_dnsheader}" ] && printf '%b' "${adb_dnsheader}"
			[ -s "${adb_tmpdir}/tmp.add.allowlist" ] && "${adb_catcmd}" "${adb_tmpdir}/tmp.add.allowlist"
			[ "${adb_safesearch}" = "1" ] && "${adb_catcmd}" "${adb_tmpdir}/tmp.safesearch."* 2>>"${adb_errorlog}"
			if [ "${adb_dnsdeny}" = "1" ]; then
				f_dnsdeny "${adb_tmpdir}/${adb_dnsfile}"
			else
				"${adb_catcmd}" "${adb_tmpdir}/${adb_dnsfile}"
			fi
		} >"${file_name}"
		"${adb_rmcmd}" -f "${adb_tmpdir}/${adb_dnsfile}"
		if [ "${adb_dnsshift}" = "1" ] && [ ! -L "${adb_dnsdir}/${adb_dnsfile}" ]; then
			"${adb_lncmd}" -fs "${file_name}" "${adb_dnsdir}/${adb_dnsfile}"
		elif [ "${adb_dnsshift}" = "0" ] && [ -s "${adb_backupdir}/${adb_dnsfile}" ]; then
			"${adb_rmcmd}" -f "${adb_backupdir}/${adb_dnsfile}"
		fi
		out_rc="0"
		;;
	esac
	{ [ "${mode}" = "final" ] || [ "${adb_debug}" = "1" ]; } && f_count "${mode}" "${file_name}"
	out_rc="${out_rc:-"${in_rc}"}"

	f_log "debug" "f_list   ::: name: ${src_name:-"-"}, mode: ${mode}, cnt: ${adb_cnt}, in_rc: ${in_rc}, out_rc: ${out_rc}"
	return "${out_rc}"
}

# top level domain compression
#
f_tld() {
	local cnt_tld source="${1}" temp_tld="${1}.tld" allow="${adb_tmpdir}/tmp.rem.allowlist"

	# single pass over the reversed, sorted input:
	# drop subdomains of already kept domains, unreverse the rest and drop allowlisted (sub-) domains
	# a stack of kept parents is needed, as siblings like 'com.foo-bar' sort between 'com.foo' and 'com.foo.sub'
	#
	if "${adb_awkcmd}" -v allow="${allow}" '
		BEGIN { FS = "."; while ((getline line <allow) > 0) del[line] }
		{
			while (sp > 0 && index($0, stk[sp]) != 1) sp--
			if (sp > 0 && index($0, stk[sp] ".") == 1) next
			stk[++sp] = $0
			dom = $1
			if (dom in del) next
			for (i = 2; i <= NF; i++) {
				dom = $i "." dom
				if (dom in del) next
			}
			print dom
		}
	' "${source}" >"${temp_tld}"; then
		"${adb_mvcmd}" -f "${temp_tld}" "${source}"
		[ "${adb_debug}" = "1" ] && cnt_tld="$(f_count tld "${source}" "var")"
	else
		"${adb_rmcmd}" -f "${temp_tld}"
	fi

	f_log "debug" "f_tld    ::: name: -, cnt: ${adb_cnt:-"-"}, cnt_tld: ${cnt_tld:-"-"}"
}

# suspend/resume adblock processing
#
f_switch() {
	local status switch rc="0" mode="${1}"

	json_init
	json_load_file "${adb_rtfile}" >/dev/null 2>&1
	json_get_var status "adblock_status"
	f_env

	# suspend adblock processing
	#
	if [ "${status}" = "enabled" ] && [ "${mode}" = "suspend" ]; then

		# suspend via external DNS bridge
		#
		if { [ -n "${adb_bridgednsv4}" ] || [ -n "${adb_bridgednsv6}" ]; } && [ "${adb_nftbridge}" = "1" ]; then
			if "${adb_nftcmd}" list chain inet adblock dns-bridge >/dev/null 2>&1; then
				if [ -n "${adb_bridgednsv4}" ]; then
					"${adb_nftcmd}" add rule inet adblock dns-bridge meta nfproto ipv4 meta l4proto { udp, tcp } th dport 53 counter dnat to ${adb_bridgednsv4}:53 2>>"${adb_errorlog}"
					rc="${?}"
				fi
				if [ -n "${adb_bridgednsv6}" ]; then
					"${adb_nftcmd}" add rule inet adblock dns-bridge meta nfproto ipv6 meta l4proto { udp, tcp } th dport 53 counter dnat to [${adb_bridgednsv6}]:53 2>>"${adb_errorlog}"
					rc="$((rc + $?))"
				fi
				[ "${rc}" = "0" ] && switch="nft"
			fi

		# suspend via local DNS
		#
		else
			if [ "${adb_dnsshift}" = "0" ] && [ -f "${adb_finaldir}/${adb_dnsfile}" ]; then
				"${adb_mvcmd}" -f "${adb_finaldir}/${adb_dnsfile}" "${adb_backupdir}/${adb_dnsfile}"
				printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
				switch="dns"
			elif [ "${adb_dnsshift}" = "1" ] && [ -L "${adb_dnsdir}/${adb_dnsfile}" ]; then
				"${adb_rmcmd}" -f "${adb_dnsdir}/${adb_dnsfile}"
				printf '%b' "${adb_dnsheader}" >"${adb_dnsdir}/${adb_dnsfile}"
				switch="dns"
			fi
		fi

	# resume adblock processing
	#
	elif [ "${status}" = "paused" ] && [ "${mode}" = "resume" ]; then

		# resume via external DNS bridge
		#
		if [ "${adb_nftbridge}" = "1" ] && "${adb_nftcmd}" list chain inet adblock dns-bridge >/dev/null 2>&1; then
			if "${adb_nftcmd}" flush chain inet adblock dns-bridge 2>>"${adb_errorlog}"; then
				switch="nft"
			fi

		# resume via local DNS
		#
		else
			if [ "${adb_dnsshift}" = "0" ] && [ -f "${adb_backupdir}/${adb_dnsfile}" ]; then
				"${adb_mvcmd}" -f "${adb_backupdir}/${adb_dnsfile}" "${adb_finaldir}/${adb_dnsfile}"
				switch="dns"
			elif [ "${adb_dnsshift}" = "1" ] && [ ! -L "${adb_dnsdir}/${adb_dnsfile}" ]; then
				"${adb_lncmd}" -fs "${adb_finaldir}/${adb_dnsfile}" "${adb_dnsdir}/${adb_dnsfile}"
				switch="dns"
			fi
		fi
	fi

	# update runtime information and log action
	#
	if [ "${switch}" = "nft" ]; then
		f_jsnup "${mode}"
		f_log "info" "${mode} adblock service via external DNS bridge"
	elif [ "${switch}" = "dns" ]; then
		f_dnsup
		f_jsnup "${mode}"
		f_log "info" "${mode} adblock service via local DNS"
	else
		f_jsnup "${status}"
	fi
	f_rmtemp
}

# search blocklist for certain (sub-)domains
#
f_search() {
	local rc cnt res search result result_tmp result_flag result_tc backup_tmp prefix suffix field search_start search_end search_timeout="90" domain="${1}" tld query

	# prepare result files
	#
	result="${adb_rundir}/adblock.search"
	result_tmp="${adb_rundir}/adblock.search.tmp"
	result_flag="${adb_rundir}/adblock.search.flag"

	# input validation
	#
	case "${domain}" in
	"" | *[!a-zA-Z0-9.-]* | -* | *- | *..* | *.)
		printf '%s\n' "::: invalid input, please submit a single (sub-)domain :::"
		printf '%s\n' "::: invalid input, please submit a single (sub-)domain :::" >"${result}"
		return
		;;
	esac

	# length validation for domain part, max. 253 characters according to RFC 1035
	#
	case "${#domain}" in
	[0-9] | [1-9][0-9] | 1[0-9][0-9] | 2[0-4][0-9] | 25[0-3]) ;;

	*)
		printf '%s\n' "::: invalid input, domain exceeds 253 characters :::"
		printf '%s\n' "::: invalid input, domain exceeds 253 characters :::" >"${result}"
		return
		;;
	esac

	# the blocklists and backups are lowercase
	#
	domain="$(printf '%s' "${domain}" | "${adb_awkcmd}" '{print tolower($0)}')"
	query="${domain}"
	tld="${domain#*.}"

	# search blocklist
	#
	case "${adb_dns}" in
	"unbound")
		prefix='local-zone: .*["\.]'
		suffix='" always_nxdomain'
		field="3"
		;;
	"named")
		prefix=""
		suffix=' CNAME \.'
		field="1"
		;;
	"kresd")
		prefix=""
		suffix=' CNAME \.'
		field="1"
		;;
	"smartdns")
		prefix='address .*.*[\/\.]'
		suffix='\/#'
		field="3"
		;;
	"raw")
		prefix=""
		suffix=""
		field="1"
		;;
	esac

	# initialize result_tmp and start search
	#
	: >"${result_tmp}"
	read -r search_start _ <"/proc/uptime"
	search_start="${search_start%.*}"

	# search recursively for max. 3 domain and its parent domains until tld is reached
	#
	while :; do
		search="${domain//./\\.}"
		if [ "${adb_dns}" = "dnsmasq" ]; then
			res="$("${adb_awkcmd}" -F '/' -v s="${domain}" '
				$1 == "local=" && $NF == "" && index($0, s "/") {
					for (f = 2; f < NF; f++) {
						if ($f == s || (length($f) > length(s) && substr($f, length($f) - length(s)) == "." s)) {
							i++
							if (i <= 3) {
								printf "  + %s\n", $f
							} else {
								printf "  + %s\n", "[...]"
								exit
							}
						}
					}
				}
			' "${adb_finaldir}/${adb_dnsfile}")"
		else
			res="$("${adb_awkcmd}" -F '/|\"|\t| ' "/^(${prefix}${search}${suffix})$/{i++;if(i<=3){printf \"  + %s\n\",\$${field}}else if(i==4){printf \"  + %s\n\",\"[...]\";exit}}" "${adb_finaldir}/${adb_dnsfile}")"
		fi
		printf '%s\n%s\n%s\n' ":::" "::: domain '${domain}' in active blocklist" ":::" >>"${result_tmp}"
		printf '%s\n\n' "${res:-"  - no match"}" >>"${result_tmp}"
		[ "${domain}" = "${tld}" ] && break
		domain="${tld}"
		tld="${domain#*.}"
	done

	# search exactly for the given domain in backup files and local block-/allowlist
	#
	if [ -d "${adb_backupdir}" ]; then
		search="${query//./\\.}"
		printf '%s\n%s\n%s\n' ":::" "::: domain '${query}' in backups and in local block-/allowlist" ":::" >>"${result_tmp}"
		"${adb_rmcmd}" -f "${result_flag}" "${adb_rundir}"/adblock.search.frag.*
		result_tc=""
		cnt="1"
		for file in "${adb_backupdir}/adb_list".*.gz "${adb_blocklist}" "${adb_allowlist}"; do
			read -r search_end _ </proc/uptime
			if [ "$((${search_end%.*} - search_start))" -gt "${search_timeout}" ]; then
				result_tc="1"
				break
			fi

			# parallel search in backup files and local block-/allowlist,
			# exit as soon as a match is found or after 3 matches per file, if more matches are found print truncated result and stop searching further files
			(
				backup_tmp="${adb_rundir}/adblock.search.frag.$$.${cnt}"
				suffix="${file##*.}"
				if [ "${suffix}" = "gz" ]; then
					if [ "${adb_tld}" = "1" ]; then
						"${adb_zcatcmd}" "${file}" 2>>"${adb_errorlog}" |
							"${adb_awkcmd}" 'BEGIN{FS="."}NF==2{print $2"."$1;next}NF==3{print $3"."$2"."$1;next}{for(f=NF;f>1;f--)printf "%s.",$f;print $1}' |
							"${adb_awkcmd}" -v f="${file##*/}" "BEGIN{rc=1};/^($search|.*\\.${search})\$/{i++;if(i<=3){printf \"  + %-30s%s\n\",f,\$1;rc=0}else if(i==4){printf \"  + %-30s%s\n\",f,\"[...]\"}};END{exit rc}" >"${backup_tmp}"
					else
						"${adb_zcatcmd}" "${file}" 2>>"${adb_errorlog}" |
							"${adb_awkcmd}" -v f="${file##*/}" "BEGIN{rc=1};/^($search|.*\\.${search})\$/{i++;if(i<=3){printf \"  + %-30s%s\n\",f,\$1;rc=0}else if(i==4){printf \"  + %-30s%s\n\",f,\"[...]\"}};END{exit rc}" >"${backup_tmp}"
					fi
					rc="${?}"
				else
					"${adb_awkcmd}" -v f="${file##*/}" "BEGIN{rc=1};/^($search|.*\\.${search})\$/{i++;if(i<=3){printf \"  + %-30s%s\n\",f,\$1;rc=0}else if(i==4){printf \"  + %-30s%s\n\",f,\"[...]\"}};END{exit rc}" "${file}" >"${backup_tmp}"
					rc="${?}"
				fi
				if [ "${rc}" = "0" ]; then
					: >"${result_flag}"
					"${adb_catcmd}" "${backup_tmp}" >>"${result_tmp}"
				fi
				"${adb_rmcmd}" -f "${backup_tmp}"
			) &
			[ "${cnt}" -ge "${adb_cores}" ] && wait -n
			cnt="$((cnt + 1))"
		done
		wait

		# if result_tc is set, it means that the search was stopped due to timeout and the result is truncated
		#
		if [ -n "${result_tc}" ]; then
			printf '%s\n\n' "  - [...]" >>"${result_tmp}"
		elif [ ! -f "${result_flag}" ]; then
			printf '%s\n\n' "  - no match" >>"${result_tmp}"
		fi
	fi
	"${adb_mvcmd}" -f "${result_tmp}" "${result}"
	"${adb_catcmd}" "${result}" 2>>"${adb_errorlog}"
}

# update runtime information
#
f_jsnup() {
	local s_shift s_custom s_unfiltered s_filtered s_remote s_bridge s_force s_flush s_tld s_search s_report s_mail
	local s_jail s_debug pid pids object feeds end_time runtime backup_cnt dns dns_ver free_mem custom_feed="0" status="${1:-"enabled"}"
	local vm_mem dns_mem="0" duration jail="0" nft_unfiltered="0" nft_filtered="0" nft_remote="0" nft_bridge="0" nft_force="0"

	# get DNS memory usage and version
	#
	if adb_dnspid="$("${adb_ubuscmd}" -S call service list 2>>"${adb_errorlog}" |
		"${adb_jsoncmd}" -l1 -e "@[\"${adb_dns}\"].instances.*.pid")" && [ -n "${adb_dnspid}" ]; then
		pids="$("${adb_pgrepcmd}" -P "${adb_dnspid}" 2>>"${adb_errorlog}")"
		for pid in ${adb_dnspid} ${pids}; do
			vm_mem="$("${adb_awkcmd}" '/^VmRSS/{printf "%d", $2}' "/proc/${pid}/status" 2>>"${adb_errorlog}")"
			dns_mem="$((dns_mem + ${vm_mem:-0}))"
		done
		case "${adb_dns}" in
		"kresd")
			dns="knot-resolver"
			;;
		"named")
			dns="bind-server"
			;;
		"unbound")
			dns="unbound-daemon"
			;;
		"dnsmasq")
			dns='dnsmasq", "dnsmasq-full", "dnsmasq-dhcpv6'
			;;
		esac
		dns_ver="$(printf '%s' "${adb_packages}" | "${adb_jsoncmd}" -ql1 -e "@.packages[\"${dns:-"${adb_dns}"}\"]")"
		dns_mem="$("${adb_awkcmd}" -v mem="${dns_mem}" 'BEGIN{printf "%.2f", mem/1024}' 2>>"${adb_errorlog}")"
	fi
	free_mem="$(f_mem float)"

	# check for custom feed and nft rules
	#
	[ -s "${adb_customfeedfile}" ] && custom_feed="1"
	if [ "${adb_nftforce}" = "1" ] && [ -n "${adb_nftdevforce}" ] && [ -n "${adb_nftportforce}" ]; then
		nft_force="1"
	fi
	if [ "${adb_nftallow}" = "1" ] &&
		{ [ -n "${adb_nftmacallow}" ] || [ -n "${adb_nftdevallow}" ]; } &&
		{ [ -n "${adb_allowdnsv4}" ] || [ -n "${adb_allowdnsv6}" ]; }; then
		nft_unfiltered="1"
	fi
	if [ "${adb_nftblock}" = "1" ] &&
		{ [ -n "${adb_nftmacblock}" ] || [ -n "${adb_nftdevblock}" ]; } &&
		{ [ -n "${adb_blockdnsv4}" ] || [ -n "${adb_blockdnsv6}" ]; }; then
		nft_filtered="1"
	fi
	if [ "${adb_nftremote}" = "1" ] && [ -n "${adb_nftmacremote}" ] &&
		{ [ -n "${adb_remotednsv4}" ] || [ -n "${adb_remotednsv6}" ]; }; then
		nft_remote="1"
	fi
	if [ "${adb_nftbridge}" = "1" ] &&
		{ [ -n "${adb_bridgednsv4}" ] || [ -n "${adb_bridgednsv6}" ]; }; then
		nft_bridge="1"
	fi

	# update runtime information based on status
	#
	case "${status}" in
	"enabled")
		if [ -n "${adb_starttime}" ]; then
			read -r end_time _ <"/proc/uptime"
			end_time="${end_time%.*}"
			duration="$(((end_time - adb_starttime) / 60))m $(((end_time - adb_starttime) % 60))s"
		fi
		runtime="mode: ${adb_action}, date / time: $(date "+%Y-%m-%d %H:%M:%S"), duration: ${duration:-"-"}, memory: ${free_mem:-0} MB available"
		;;
	"resume")
		status="enabled"
		;;
	"suspend")
		adb_cnt="0"
		status="paused"
		;;
	*)
		adb_cnt="0"
		;;
	esac

	# update runtime file and send mail if enabled
	#
	json_init
	if json_load_file "${adb_rtfile}" >/dev/null 2>&1; then
		json_get_var backup_cnt "backup_cnt"
		[ "${1}" = "resume" ] && adb_cnt="${backup_cnt:-"0"}"
		[ -z "${adb_cnt}" ] && json_get_var adb_cnt "blocked_domains"
		[ "${status}" = "enabled" ] && backup_cnt="${adb_cnt}"
		[ -z "${runtime}" ] && json_get_var runtime "last_run"
		if [ "${status}" = "enabled" ]; then
			if [ "${adb_jail}" = "1" ] && [ -n "${adb_dnsstop}" ]; then
				jail="1"
				adb_cnt="0"
				feeds="restrictive jail (allowlist-only)"
			else
				feeds="$(printf '%s\n' ${adb_feed} | "${adb_sortcmd}" | "${adb_xargscmd}")"
			fi
		fi
	fi

	# map flag values to status characters
	#
	case "${adb_dnsshift}" in "1") s_shift="✔" ;; *) s_shift="✘" ;; esac
	case "${custom_feed}" in "1") s_custom="✔" ;; *) s_custom="✘" ;; esac
	case "${nft_unfiltered}" in "1") s_unfiltered="✔" ;; *) s_unfiltered="✘" ;; esac
	case "${nft_filtered}" in "1") s_filtered="✔" ;; *) s_filtered="✘" ;; esac
	case "${nft_remote}" in "1") s_remote="✔" ;; *) s_remote="✘" ;; esac
	case "${nft_bridge}" in "1") s_bridge="✔" ;; *) s_bridge="✘" ;; esac
	case "${nft_force}" in "1") s_force="✔" ;; *) s_force="✘" ;; esac
	case "${adb_dnsflush}" in "1") s_flush="✔" ;; *) s_flush="✘" ;; esac
	case "${adb_tld}" in "1") s_tld="✔" ;; *) s_tld="✘" ;; esac
	case "${adb_safesearch}" in "1") s_search="✔" ;; *) s_search="✘" ;; esac
	case "${adb_report}" in "1") s_report="✔" ;; *) s_report="✘" ;; esac
	case "${adb_mail}" in "1") s_mail="✔" ;; *) s_mail="✘" ;; esac
	case "${jail}" in "1") s_jail="✔" ;; *) s_jail="✘" ;; esac
	case "${adb_debug}" in "1") s_debug="✔" ;; *) s_debug="✘" ;; esac

	# update runtime file
	#
	printf '%s\n' "{}" >"${adb_rtfile}"
	json_init
	json_load_file "${adb_rtfile}" >/dev/null 2>&1
	json_add_string "adblock_status" "${status}"
	json_add_string "frontend_ver" "${adb_fver}"
	json_add_string "backend_ver" "${adb_bver}"
	json_add_string "blocked_domains" "${adb_cnt:-"0"}"
	json_add_string "backup_cnt" "${backup_cnt:-"0"}"
	json_add_array "active_feeds"
	for object in ${feeds:-"-"}; do
		json_add_string "${object}" "${object}"
	done
	json_close_array
	json_add_string "dns_backend" "${adb_dns:-"-"} (${dns_ver:-"-"}), ${adb_finaldir:-"-"}, ${dns_mem:-"0"} MB"
	json_add_string "run_ifaces" "trigger: ${adb_trigger:-"-"}, report: ${adb_repiface:-"-"}"
	json_add_string "run_information" "base: ${adb_basedir}, dns: ${adb_dnsdir}, backup: ${adb_backupdir}, report: ${adb_reportdir}, error: ${adb_errorlog}"
	json_add_string "run_flags" "shift: ${s_shift}, custom feed: ${s_custom}, ext. DNS (std/prot/remote/bridge): ${s_unfiltered}/${s_filtered}/${s_remote}/${s_bridge}, force: ${s_force}, flush: ${s_flush}, tld: ${s_tld}, search: ${s_search}, report: ${s_report}, mail: ${s_mail}, jail: ${s_jail}, debug: ${s_debug}"
	json_add_string "last_run" "${runtime:-"-"}"
	json_add_string "system_info" "cores: ${adb_cores}, fetch: ${adb_fetchcmd##*/}, ${adb_sysver}"
	json_dump >"${adb_rtfile}"

	if [ "${adb_mail}" = "1" ] && [ -x "${adb_mailservice}" ] && [ "${status}" = "enabled" ] && [ "${adb_action}" != "resume" ]; then
		"${adb_mailservice}" >/dev/null 2>&1
	fi
}

# write to syslog
#
f_log() {
	local class="${1}" log_msg="${2}"

	if [ -n "${log_msg}" ] && { [ "${class}" != "debug" ] || [ "${adb_debug}" = "1" ]; }; then
		if [ -x "${adb_loggercmd}" ]; then
			"${adb_loggercmd}" -p "${class}" -t "adblock-${adb_bver:-"n/a"}[${$}]" "${log_msg::512}"
		else
			printf '%s %s %s\n' "${class}" "adblock-${adb_bver:-"n/a"}[${$}]" "${log_msg::512}" >&2
		fi
		if [ "${class}" = "err" ] || [ "${class}" = "emerg" ]; then
			[ "${adb_action}" != "mail" ] && f_rmdns
			[ -s "${adb_rtfile}" ] && f_jsnup "error"
			exit 1
		fi
	fi
}

# main function for blocklist processing
#
f_main() {
	local src_name src_domain src_rset src_url src_cat src_item src_list src_entries src_suffix src_rc entry cnt
	local src_tmpcat src_tmparchive src_tmpload src_tmprmfile src_tmpfile rm_file seen_domains feed_restore map_domain

	# allow- and blocklist preparation
	#
	for entry in ${adb_locallist}; do
		f_list "${entry}" "${entry}"
	done

	# jail mode preparation
	#
	if [ "${adb_jail}" = "1" ] && [ -n "${adb_dnsstop}" ]; then
		if [ -s "${adb_tmpdir}/${adb_dnsfile}" ]; then
			"${adb_mvcmd}" -f "${adb_tmpdir}/${adb_dnsfile}" "${adb_finaldir}/${adb_dnsfile}"
		else
			f_log "info" "jail mode active without allowlist, blocking all queries"
			{
				printf '%b' "${adb_dnsheader}"
				printf '%b\n' "${adb_dnsstop}"
			} >"${adb_finaldir}/${adb_dnsfile}"
		fi
		chown "${adb_dnsuser}" "${adb_finaldir}/${adb_dnsfile}" 2>>"${adb_errorlog}"
		if [ "${adb_dnsshift}" = "1" ] && [ ! -L "${adb_dnsdir}/${adb_dnsfile}" ]; then
			"${adb_lncmd}" -fs "${adb_finaldir}/${adb_dnsfile}" "${adb_dnsdir}/${adb_dnsfile}"
		elif [ "${adb_dnsshift}" = "0" ] && [ -s "${adb_backupdir}/${adb_dnsfile}" ]; then
			"${adb_rmcmd}" -f "${adb_backupdir}/${adb_dnsfile}"
		fi
		if f_dnsup; then
			if [ "${adb_action}" != "resume" ]; then
				f_jsnup "enabled"
			fi
			f_log "info" "restrictive jail mode enabled successfully (${adb_sysver})"
		else
			f_log "err" "dns backend restart in jail mode failed"
		fi
		f_rmtemp
		return
	fi

	# safe search preparation
	#
	if [ "${adb_safesearch}" = "1" ] && [ "${adb_dnssafesearch}" = "1" ]; then
		[ -z "${adb_safesearchlist}" ] && adb_safesearchlist="google bing brave duckduckgo pixabay yandex youtube"
		cnt="1"
		for entry in ${adb_safesearchlist}; do
			(
				f_list safesearch "${entry}"
			) &
			[ "${cnt}" -ge "${adb_cores}" ] && wait -n
			cnt="$((cnt + 1))"
		done
		wait
	fi

	# add map service domain to allowlist if map is enabled
	#
	if [ "${adb_map}" = "1" ] && [ "${adb_dnsallow}" = "1" ] && [ -n "${adb_geourl}" ]; then
		map_domain="$(f_urlhost "${adb_geourl}")"
		if [ -n "${map_domain}" ]; then
			printf '%s\n' "${map_domain}" | f_dnsallow >>"${adb_tmpdir}/tmp.add.allowlist"
			printf '%s\n' "${map_domain}" >>"${adb_tmpdir}/tmp.rem.allowlist"
		fi
	fi

	# main loop
	#
	cnt="1"
	seen_domains="${map_domain}"

	# determine if feed restore should be attempted based on action
	#
	case "${adb_action}" in
	"boot" | "start" | "restart" | "resume")
		feed_restore="1"
		;;
	*)
		feed_restore="0"
		;;
	esac

	# loop through feeds defined in configuration and process them
	#
	for src_name in ${adb_feed}; do

		# check if feed is defined in configuration, if not remove it from feed list and continue with next one
		#
		if ! json_select "${src_name}" >/dev/null 2>&1; then
			f_feedrm "${src_name}"
			continue
		fi

		# get feed information
		#
		json_get_var src_url "url" >/dev/null 2>&1
		json_get_var src_rset "rule" >/dev/null 2>&1
		json_select ..
		src_tmpcat="${adb_tmpload}.${src_name}.cat"
		src_tmpload="${adb_tmpload}.${src_name}.load"
		src_tmparchive="${adb_tmpload}.${src_name}.archive"
		src_tmprmfile="${adb_tmpload}.${src_name}.remove"
		src_tmpfile="${adb_tmpfile}.${src_name}"
		src_rc=4

		# basic pre-checks
		#
		if [ -z "${src_url}" ] || [ -z "${src_rset}" ] ||
			[ "${src_rset%% *}" != "feed" ]; then
			f_list remove
			continue
		fi

		# add domains of active feed URLs to the allowlist
		#
		src_domain="$(f_urlhost "${src_url}")"
		if [ -n "${src_domain}" ] && [ "${adb_dnsallow}" = "1" ]; then
			case " ${seen_domains} " in
			*" ${src_domain} "*) ;;

			*)
				seen_domains="${seen_domains} ${src_domain}"
				printf '%s\n' "${src_domain}" | f_dnsallow >>"${adb_tmpdir}/tmp.add.allowlist"
				printf '%s\n' "${src_domain}" >>"${adb_tmpdir}/tmp.rem.allowlist"
				;;
			esac
		fi

		# download queue processing
		#
		src_cat=""
		src_entries=""

		# category handling for feeds with fixed categories
		#
		case "${src_name}" in
		"1hosts")
			src_cat="${adb_hst_feed}"
			if [ -z "${src_cat}" ]; then
				f_log "info" "feed '${src_name}' requires category configuration, skipping"
				continue
			fi
			;;
		"hagezi")
			src_cat="${adb_hag_feed}"
			if [ -z "${src_cat}" ]; then
				f_log "info" "feed '${src_name}' requires category configuration, skipping"
				continue
			fi
			;;
		"ipfire_dbl")
			src_cat="${adb_ipf_feed}"
			if [ -z "${src_cat}" ]; then
				f_log "info" "feed '${src_name}' requires category configuration, skipping"
				continue
			fi
			;;
		"stevenblack")
			src_cat="${adb_stb_feed}"
			if [ -z "${src_cat}" ]; then
				f_log "info" "feed '${src_name}' requires category configuration, skipping"
				continue
			fi
			;;
		esac

		# category handling for feeds with multiple categories
		#
		if [ -n "${src_cat}" ]; then
			(
				# restore handling on boot, resume or (re-)start
				#
				if [ "${feed_restore}" = "1" ]; then
					if f_list restore && [ -s "${src_tmpfile}" ]; then
						exit 0
					fi
				fi

				# etag handling on reload
				#
				if [ -n "${adb_etagparm}" ] && [ "${adb_action}" = "reload" ]; then
					etag_rc="0"
					src_cnt="0"
					for _ in ${src_cat}; do
						src_cnt="$((src_cnt + 1))"
					done
					for suffix in ${src_cat}; do
						if ! f_etag "${src_name}" "${src_url}" "${suffix}" "${src_cnt}"; then
							etag_rc="$((etag_rc + 1))"
						fi
					done
					if [ "${etag_rc}" = "0" ]; then
						if f_list restore && [ -s "${src_tmpfile}" ]; then
							exit 0
						fi
					fi
				fi

				# category download
				#
				for suffix in ${src_cat}; do
					"${adb_fetchcmd}" ${adb_fetchparm} "${src_tmpcat}" "${src_url}${suffix}" 2>>"${adb_errorlog}"
					src_rc="${?}"
					[ "${src_rc}" = "0" ] || break
					if [ -s "${src_tmpcat}" ]; then
						"${adb_catcmd}" "${src_tmpcat}" >>"${src_tmpload}"
						: >"${src_tmpcat}"
					fi
				done
				f_list prepare
			) &

		# normal handling for feeds without categories
		#
		else
			(
				[ "${src_name}" = "utcapitole" ] && src_cat="${adb_utc_feed}"

				# restore handling on boot, resume or (re-)start
				#
				if [ "${feed_restore}" = "1" ]; then
					if f_list restore && [ -s "${src_tmpfile}" ]; then
						exit 0
					fi
				fi

				# etag handling on reload
				#
				if [ -n "${adb_etagparm}" ] && [ "${adb_action}" = "reload" ]; then
					if f_etag "${src_name}" "${src_url}"; then
						if f_list restore && [ -s "${src_tmpfile}" ]; then
							exit 0
						fi
					fi
				fi

				# download feed and extract categories if necessary
				#
				if [ "${src_name}" = "utcapitole" ]; then
					if [ -n "${src_cat}" ]; then
						"${adb_fetchcmd}" ${adb_fetchparm} "${src_tmparchive}" "${src_url}" 2>>"${adb_errorlog}"
						src_rc="${?}"
						if [ "${src_rc}" = "0" ] && [ -s "${src_tmparchive}" ]; then
							src_suffix="${adb_src_suffix_utcapitole:-"domains"}"
							src_entries="$(tar -tzf "${src_tmparchive}" 2>>"${adb_errorlog}" | "${adb_awkcmd}" \
								-v cats="${src_cat}" -v sfx="${src_suffix}" '
									BEGIN { n = split(cats, c, " ") }
									{ for (i = 1; i <= n; i++) if ($0 ~ "(^|/)" c[i] "/" sfx "$") print }')"
							if [ -n "${src_entries}" ]; then
								tar -xOzf "${src_tmparchive}" ${src_entries} 2>>"${adb_errorlog}" >"${src_tmpload}"
								src_rc="${?}"
							fi
							: >"${src_tmparchive}"
						fi
					fi
				else
					"${adb_fetchcmd}" ${adb_fetchparm} "${src_tmpload}" "${src_url}" 2>>"${adb_errorlog}"
					src_rc="${?}"
				fi
				f_list prepare
			) &
		fi
		[ "${cnt}" -ge "${adb_cores}" ] && wait -n
		cnt="$((cnt + 1))"
	done
	wait

	# prune feeds that failed restore inside the background subshells
	#
	for rm_file in "${adb_tmpload}".*.remove; do
		[ -f "${rm_file}" ] || continue
		while read -r entry; do
			f_feedrm "${entry}"
		done <"${rm_file}"
	done

	# drop orphaned etag entries for feeds no longer in the active feed list
	#
	[ "${adb_action}" = "reload" ] && f_etag "${adb_feed}" "" "" "" "sweep"

	# tld compression and dns restart
	#
	if f_list merge && [ -s "${adb_tmpdir}/${adb_dnsfile}" ]; then
		[ "${adb_tld}" = "1" ] && f_tld "${adb_tmpdir}/${adb_dnsfile}"
		f_list final
	else
		printf '%b' "${adb_dnsheader}" >"${adb_finaldir}/${adb_dnsfile}"
		f_log "info" "no merge input, only header written to ${adb_finaldir}/${adb_dnsfile}"
	fi
	chown "${adb_dnsuser}" "${adb_finaldir}/${adb_dnsfile}" 2>>"${adb_errorlog}"
	if f_dnsup; then
		f_log "info" "blocklist with overall ${adb_cnt} blocked domains loaded successfully (${adb_sysver})"
		[ "${adb_action}" != "resume" ] && f_jsnup "enabled"
	else
		f_log "err" "dns backend restart with adblock blocklist failed"
	fi
	f_rmtemp
}

# trace dns queries via tcpdump and prepare a report
#
f_report() {
	local report_raw report_txt content status total start end start_date start_time end_date end_time blocked percent top_list top array item index value key key_list
	local domain rc map_seen ip request requests iface_v4 iface_v6 ip_v4 ip_v6 map_jsn cnt report_srt report_jsn top_tmpclients top_tmpdomains top_tmpblocked
	local file jsn eflag resolve="-nn" action="${1}" top_count="${2:-"10"}" res_count="${3:-"50"}" search="${4:-"+"}"

	report_raw="${adb_reportdir}/adb_report.raw"
	report_srt="${adb_reportdir}/adb_report.srt"
	report_jsn="${adb_reportdir}/adb_report.jsn"
	report_txt="${adb_reportdir}/adb_mailreport.txt"
	top_tmpclients="${adb_reportdir}/top_clients.tmp"
	top_tmpdomains="${adb_reportdir}/top_domains.tmp"
	top_tmpblocked="${adb_reportdir}/top_blocked.tmp"
	map_jsn="${adb_reportdir}/adb_map.jsn"

	# build report
	#
	if [ "${action}" != "json" ]; then
		: >"${report_srt}" >"${report_txt}" >"${report_jsn}" >"${map_jsn}"
		: >"${top_tmpclients}" >"${top_tmpdomains}" >"${top_tmpblocked}"
		[ "${adb_represolve}" = "1" ] && resolve=""
		[ "${adb_repiface}" != "any" ] && eflag="-e"
		[ "${action}" = "gen" ] && printf '%s\n' "0" >"${adb_rundir}/adblock.report"
		cnt="1"
		for file in "${adb_reportdir}/adb_report.pcap"*; do
			[ -s "${file}" ] || continue
			(
				"${adb_dumpcmd}" ${resolve} ${eflag} --immediate-mode -tttt -T domain -r "${file}" 2>/dev/null |
					"${adb_awkcmd}" -v repiface="${adb_repiface}" '
					BEGIN {
						pending = 0
					}
					# ignore Reverse DNS
					/\.in-addr\.arpa/ || /\.ip6\.arpa/ { next }
					# domain request parser (with optional EDNS marker support)
					/\+[[:space:]]+(\[[0-9a-z]*\][[:space:]]+)?(A\?|AAAA\?)/ {
						# drop unresolved previous query
						if (pending)
							pending = 0
						date = $1
						split($2, t, ":")
						time = t[1] ":" t[2] ":" substr(t[3],1,2)
						# client/interface detection
						vlan = ""
						for (i = 3; i < NF; i++) {
							if ($i == "vlan") {
								vlan = $(i+1)
								sub(/,$/, "", vlan)
							}
							if ($i == ">" && $(i+1) ~ /:$/) break
						}
						client = $(i-1)
						if (repiface == "any") {
							interface = ($3 ~ /^IP6?$/) ? "any" : $3
						} else {
							interface = (vlan != "") ? repiface "." vlan : repiface
						}
						sub(/\.[0-9]+$/, "", client)
						domain = $(NF-1)
						sub(/[,\.]+$/, "", domain)
						if (domain ~ /\.lan$/) next
						if (domain !~ /\./) next
						if (domain ~ /[\/:]/) next
						qtype = $(NF-2)
						sub(/\?$/, "", qtype)
						last_date = date
						last_time = time
						last_client = client
						last_interface = interface
						last_domain = domain
						last_qtype  = qtype
						pending  = 1
						next
					}
					# ok answer
					/ (A|AAAA|CNAME) / && !/NXDomain/ && !/ServFail/ {
						if (pending) {
							printf "%s\t%s\t%s\t%s\t%s\t%s\tOK\n",
							last_date, last_time, last_client, last_interface, last_qtype, last_domain
							pending = 0
						}
						next
					}
					# nxdomain answer
					/ NXDomain/ {
						if (pending) {
							printf "%s\t%s\t%s\t%s\t%s\t%s\tNX\n",
							last_date, last_time, last_client, last_interface, last_qtype, last_domain
							pending = 0
						}
						next
					}
					# servfail answer
					/ ServFail/ {
						if (pending) {
							printf "%s\t%s\t%s\t%s\t%s\t%s\tSF\n",
							last_date, last_time, last_client, last_interface, last_qtype, last_domain
							pending = 0
						}
						next
					}
				' >"${report_raw}.${cnt}"
			) &
			[ "${cnt}" -ge "${adb_cores}" ] && wait -n
			cnt="$((cnt + 1))"
		done
		wait
		for file in "${report_raw}".*; do
			[ -s "${file}" ] || continue
			"${adb_sortcmd}" ${adb_srtopts} -ru "${report_raw}".* >"${report_srt}"
			"${adb_rmcmd}" -f "${report_raw}".*
			break
		done

		# build json
		#
		if [ -s "${report_srt}" ]; then
			start="$("${adb_awkcmd}" 'END{printf "%s_%s",$1,$2}' "${report_srt}")"
			end="$("${adb_awkcmd}" 'NR==1{printf "%s_%s",$1,$2}' "${report_srt}")"
			total="$(f_count tld "${report_srt}" "var")"
			blocked="$("${adb_awkcmd}" '{if($7=="NX")cnt++}END{printf "%s",cnt+0}' "${report_srt}")"
			percent="$("${adb_awkcmd}" -v t="${total}" -v b="${blocked}" 'BEGIN{ if(t>0) printf "%.2f%s",b/t*100,"%"; else printf "0.00%%"}')"
			{
				printf '%s\n' "{ "
				printf '\t%s\n' "\"start_date\": \"${start%_*}\", "
				printf '\t%s\n' "\"start_time\": \"${start#*_}\", "
				printf '\t%s\n' "\"end_date\": \"${end%_*}\", "
				printf '\t%s\n' "\"end_time\": \"${end#*_}\", "
				printf '\t%s\n' "\"total\": \"${total}\", "
				printf '\t%s\n' "\"blocked\": \"${blocked}\", "
				printf '\t%s\n' "\"percent\": \"${percent}\", "
			} >"${report_jsn}"

			# build top list counters
			#
			"${adb_awkcmd}" '
				{
					if (NF < 7) {
						next
					}
					client = $3
					domain = $6
					rc = $7

					if (domain == "" || domain == "-") {
						next
					}

					sub(/[\.]+$/, "", domain)
					domain = tolower(domain)

					clients[client]++
					if (rc == "OK") {
						ok_domain[domain]++
					}
					else if (rc == "NX") {
						nx_domain[domain]++
					}
					all_domain[domain]++
				}
			END {
				for (c in clients) {
					printf "%d %s\n", clients[c], c > "'"${top_tmpclients}"'"
				}
				for (d in all_domain) {
					if (d in ok_domain) {
						printf "%d %s\n", ok_domain[d], d > "'"${top_tmpdomains}"'"
					}
					if (d in nx_domain) {
						printf "%d %s\n", nx_domain[d], d > "'"${top_tmpblocked}"'"
					}
				}
			}
			' "${report_srt}"

			# build json top lists
			#
			top_list="top_clients top_domains top_blocked"
			for top in ${top_list}; do
				printf '\t"%s": [ ' "${top}" >>"${report_jsn}"
				case "${top}" in
				top_clients)
					"${adb_sortcmd}" ${adb_srtopts} -nr "${top_tmpclients}" |
						"${adb_awkcmd}" -v top_count="${top_count}" '
							function jclean(s){gsub(/[[:cntrl:]"\\]/,"",s);return s}
							BEGIN { ORS=""; OFS="" }
							NR==1 {
								printf "\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
							NR>1 && NR<=top_count {
								printf ",\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
						' >>"${report_jsn}"
					;;
				top_domains)
					"${adb_sortcmd}" ${adb_srtopts} -nr "${top_tmpdomains}" |
						"${adb_awkcmd}" -v top_count="${top_count}" '
							function jclean(s){gsub(/[[:cntrl:]"\\]/,"",s);return s}
							BEGIN { ORS=""; OFS="" }
							NR==1 {
								printf "\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
							NR>1 && NR<=top_count {
								printf ",\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
						' >>"${report_jsn}"
					;;
				top_blocked)
					"${adb_sortcmd}" ${adb_srtopts} -nr "${top_tmpblocked}" |
						"${adb_awkcmd}" -v top_count="${top_count}" '
							function jclean(s){gsub(/[[:cntrl:]"\\]/,"",s);return s}
							BEGIN { ORS=""; OFS="" }
							NR==1 {
								printf "\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
							NR>1 && NR<=top_count {
								printf ",\n\t\t{\n\t\t\t\"count\": \"%s\",\n\t\t\t\"address\": \"%s\"\n\t\t}", $1, jclean($2)
							}
						' >>"${report_jsn}"
					;;
				esac
				printf '\n\t],\n' >>"${report_jsn}"
			done
			"${adb_rmcmd}" -f "${top_tmpclients}" "${top_tmpdomains}" "${top_tmpblocked}"

			# build json request list
			#
			search="${search//[!a-zA-Z0-9._:-]/}"
			case "${res_count}" in
			'' | *[!0-9]*)
				res_count="50"
				;;
			esac
			"${adb_awkcmd}" -v search="${search}" -v res_count="${res_count}" '
				BEGIN {
					i = 0
					printf "\t\"requests\": [\n"
				}
				function jclean(s){gsub(/[[:cntrl:]"\\]/,"",s);return s}

				# only match if search is empty or non-empty and NF == 7
				((search == "" || index($0, search)) && NF == 7) {
					i++
					if (res_count > 0 && i > res_count) {
						next
					}
					if (i > 1) {
						printf ",\n"
					}

					printf "\n\t\t{\n"
					printf "\t\t\t\"date\": \"%s\",\n", $1
					printf "\t\t\t\"time\": \"%s\",\n", $2
					printf "\t\t\t\"client\": \"%s\",\n", jclean($3)
					printf "\t\t\t\"iface\": \"%s\",\n", jclean($4)
					printf "\t\t\t\"type\": \"%s\",\n", $5
					printf "\t\t\t\"domain\": \"%s\",\n", jclean($6)
					printf "\t\t\t\"rc\": \"%s\"\n", $7
					printf "\t\t}"
				}
				END {
					printf "\n\t]\n}\n"
			}' "${report_srt}" >>"${report_jsn}"
			"${adb_rmcmd}" -f "${report_srt}"
		fi

		# retrieve/prepare map data
		#
		if [ "${adb_map}" = "1" ] && [ -s "${report_jsn}" ]; then
			cnt="1"
			network_find_wan iface_v4 && network_get_ipaddr ip_v4 "${iface_v4}"
			network_find_wan6 iface_v6 && network_get_ipaddr6 ip_v6 "${iface_v6}"
			f_fetch
			printf '%s' ",[{}" >"${map_jsn}"
			for ip in ${ip_v4} ${ip_v6}; do
				(
					"${adb_fetchcmd}" ${adb_geoparm} "${adb_geourl}/${ip}" 2>>"${adb_errorlog}" |
						"${adb_awkcmd}" -v feed="homeIP" '{printf ",{\"%s\": %s}\n",feed,$0}' >"${map_jsn}.${cnt}"
				) &
				[ "${cnt}" -ge "${adb_cores}" ] && wait -n
				cnt="$((cnt + 1))"
			done
			wait
			if [ "${cnt}" -lt "45" ]; then
				map_seen=""
				json_init
				if json_load_file "${report_jsn}" >/dev/null 2>&1; then
					json_select "requests" >/dev/null 2>&1
					json_get_keys requests >/dev/null 2>&1
					for request in ${requests}; do
						json_select "${request}" >/dev/null 2>&1
						json_get_var rc "rc" >/dev/null 2>&1
						json_get_var domain "domain" >/dev/null 2>&1
						if [ "${rc}" = "NX" ]; then
							case " ${map_seen} " in
							*" ${domain} "*) ;;

							*)
								map_seen="${map_seen} ${domain} "
								(
									"${adb_fetchcmd}" ${adb_geoparm} "${adb_geourl}/${domain}" 2>>"${adb_errorlog}" |
										"${adb_awkcmd}" -v feed="${domain}" '{printf ",{\"%s\": %s}\n",feed,$0}' >"${map_jsn}.${cnt}"
								) &
								[ "${cnt}" -ge "${adb_cores}" ] && wait -n
								cnt="$((cnt + 1))"
								[ "${cnt}" -ge "45" ] && break
								;;
							esac
						fi
						json_select ".."
					done
					wait
				fi
			fi
			for file in "${map_jsn}".*; do
				[ -s "${file}" ] || continue
				"${adb_catcmd}" "${map_jsn}".* >>"${map_jsn}" 2>/dev/null
				"${adb_rmcmd}" -f "${map_jsn}".*
				break
			done
		fi
	fi

	# output preparation
	#
	if [ -s "${report_jsn}" ] && { [ "${action}" = "cli" ] || [ "${action}" = "mail" ]; }; then
		printf '%s\n%s\n%s\n' ":::" "::: Adblock DNS Report" ":::" >>"${report_txt}"
		json_init
		json_load_file "${report_jsn}"
		json_get_keys key_list
		for key in ${key_list}; do
			json_get_var value "${key}"
			case "${key}" in
			"start_date")
				start_date="${value}"
				;;
			"start_time")
				start_time="${value}"
				;;
			"end_date")
				end_date="${value}"
				;;
			"end_time")
				end_time="${value}"
				;;
			"total")
				total="${value}"
				;;
			"blocked")
				blocked="${value}"
				;;
			"percent")
				percent="${value}"
				;;
			esac
		done
		printf '  + %s\n  + %s\n' "Start    ::: ${start_date}, ${start_time}" "End      ::: ${end_date}, ${end_time}" >>"${report_txt}"
		printf '  + %s\n  + %s %s\n' "Total    ::: ${total}" "Blocked  ::: ${blocked}" "(${percent})" >>"${report_txt}"
		top_list="top_clients top_domains top_blocked requests"
		for top in ${top_list}; do
			case "${top}" in
			"top_clients")
				item="::: Top Clients"
				;;
			"top_domains")
				item="::: Top Domains"
				;;
			"top_blocked")
				item="::: Top Blocked Domains"
				;;
			esac
			if json_get_type status "${top}" && [ "${top}" != "requests" ] && [ "${status}" = "array" ]; then
				printf '%s\n%s\n%s\n' ":::" "${item}" ":::" >>"${report_txt}"
				json_select "${top}"
				index="1"
				item=""
				while json_get_type status "${index}" && [ "${status}" = "object" ]; do
					json_get_values item "${index}"
					printf '  + %-9s::: %s\n' ${item} >>"${report_txt}"
					index="$((index + 1))"
				done
			elif json_get_type status "${top}" && [ "${top}" = "requests" ] && [ "${status}" = "array" ]; then
				printf '%s\n%s\n%s\n' ":::" "::: Latest DNS Queries" ":::" >>"${report_txt}"
				printf '%-11s%-9s%-40s%-15s%-5s%-70s%s\n' "Date" "Time" "Client" "Interface" "Type" "Domain" "Answer" >>"${report_txt}"
				json_select "${top}"
				index="1"
				while json_get_type status "${index}" && [ "${status}" = "object" ]; do
					json_get_values item "${index}"
					printf '%-11s%-9s%-40s%-15s%-5s%-70s%s\n' ${item} >>"${report_txt}"
					index="$((index + 1))"
				done
			fi
			json_select ".."
		done
		content="$("${adb_catcmd}" "${report_txt}" 2>>"${adb_errorlog}")"
		"${adb_rmcmd}" -f "${report_txt}"
	fi

	# report output
	#
	case "${action}" in
	"cli")
		printf '%s\n' "${content}"
		;;
	"json")
		if [ "${adb_map}" = "1" ] && [ -s "${map_jsn}" ]; then
			jsn="$("${adb_catcmd}" ${report_jsn} ${map_jsn} 2>>"${adb_errorlog}")"
			[ -n "${jsn}" ] && printf '[%s]]\n' "${jsn}"
		else
			jsn="$("${adb_catcmd}" "${report_jsn}" 2>>"${adb_errorlog}")"
			[ -n "${jsn}" ] && printf '[%s]\n' "${jsn}"
		fi
		;;
	"mail")
		[ "${adb_mail}" = "1" ] && [ -x "${adb_mailservice}" ] && "${adb_mailservice}" "${content}" >/dev/null 2>&1
		"${adb_rmcmd}" -f "${report_txt}"
		;;
	"gen")
		printf '%s\n' "1" >"${adb_rundir}/adblock.report"
		;;
	esac
}

# create runtime directory if it doesn't exist
#
[ ! -d "${adb_rundir}" ] && mkdir -p "${adb_rundir}"

# reference required system utilities
#
adb_mvcmd="$(f_cmd mv)"
adb_lncmd="$(f_cmd ln)"
adb_rmcmd="$(f_cmd rm)"
adb_catcmd="$(f_cmd cat)"
adb_zcatcmd="$(f_cmd zcat)"
adb_awkcmd="$(f_cmd gawk awk)"
adb_sortcmd="$(f_cmd sort)"
adb_grepcmd="$(f_cmd grep)"
adb_gzipcmd="$(f_cmd gzip)"
adb_pgrepcmd="$(f_cmd pgrep)"
adb_sedcmd="$(f_cmd sed)"
adb_findcmd="$(f_cmd find)"
adb_jsoncmd="$(f_cmd jsonfilter)"
adb_ubuscmd="$(f_cmd ubus)"
adb_loggercmd="$(f_cmd logger)"
adb_lookupcmd="$(f_cmd nslookup)"
adb_xargscmd="$(f_cmd xargs)"
adb_flockcmd="$(f_cmd flock)"
adb_dumpcmd="$(f_cmd tcpdump optional)"
adb_mailcmd="$(f_cmd msmtp optional)"
adb_logreadcmd="$(f_cmd logread optional)"
adb_nftcmd="$(f_cmd nft)"

# source required system libraries
#
if [ -r "/lib/functions.sh" ] && [ -r "/lib/functions/network.sh" ] && [ -r "/usr/share/libubox/jshn.sh" ]; then
	. "/lib/functions.sh"
	. "/lib/functions/network.sh"
	. "/usr/share/libubox/jshn.sh"
else
	f_log "err" "system libraries not found"
fi

# initial system load
#
[ -S "/var/run/ubus/ubus.sock" ] && f_load

# handle different adblock actions
#
case "${adb_action}" in
"stop")
	f_temp
	f_nftremove
	f_rmdns
	f_jsnup "stopped"
	;;
"suspend")
	[ "${adb_dns}" != "raw" ] && f_switch suspend
	;;
"resume")
	[ "${adb_dns}" != "raw" ] && f_switch resume
	;;
"report")
	f_report "${2}" "${3}" "${4}" "${5}"
	;;
"search")
	f_search "${2}"
	;;
"dump")
	f_dump
	;;
"boot" | "start" | "reload")
	f_env
	f_main
	;;
"restart")
	f_temp
	f_jsnup "processing"
	f_rmdns
	f_env
	f_main
	;;
esac
