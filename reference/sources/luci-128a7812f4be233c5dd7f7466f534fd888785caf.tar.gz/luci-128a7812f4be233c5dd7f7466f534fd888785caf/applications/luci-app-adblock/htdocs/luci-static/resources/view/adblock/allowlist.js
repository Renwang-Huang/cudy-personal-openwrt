'use strict';
'require view';
'require fs';
'require ui';

const localFile = '/etc/adblock/adblock.allowlist';
const maxSize = 100000;
let notMsg = false;

const resetScroll = () => {
	document.body.scrollTop = document.documentElement.scrollTop = 0;
};

return view.extend({
	load: function () {
		return L.resolveDefault(fs.stat(localFile), null)
			.then(function (stat) {
				if (!stat) {
					return fs.write(localFile, "").then(() => [{ size: 0 }, ""]);
				}
				return Promise.all([
					Promise.resolve(stat),
					L.resolveDefault(fs.read_direct(localFile), "")
				]);
			});
	},

	render: function (allowlist) {
		const size = allowlist[0] ? allowlist[0].size : 0;
		const content = allowlist[1] != null ? allowlist[1] : '';
		const tooBig = size >= maxSize;

		if (tooBig) {
			resetScroll();
			ui.addNotification(null, E('p', _('The allowlist is too big, unable to save modifications.')), 'error');
		}
		return E('div', { 'class': 'cbi-section cbi-section-descr' }, [
			E('p', _('This is the local adblock allowlist to always-allow certain domains.<br /> \
				<em><b>Please note:</b></em> add only one domain per line. Comments introduced with \'#\' are allowed - ip addresses, wildcards and regex are not.')),
			E('textarea', {
				'style': 'width: 100% !important; padding: 5px; font-family: monospace; margin-top: .4em',
				'spellcheck': 'false',
				'wrap': 'off',
				'rows': 25,
				'readonly': tooBig ? 'readonly' : null,
				'input': function () { notMsg = false; }
			}, [content])
		]);
	},

	handleSave: function (_ev) {
		const value = ((document.querySelector('textarea').value || '').trim().toLowerCase().replace(/[^a-z0-9.\-# \r\n]/g, '').replace(/\r\n?/g, '\n'));
		return fs.write(localFile, value + "\n")
			.then(function () {
				document.querySelector('textarea').value = value + "\n";
				resetScroll();
				if (!notMsg) {
					notMsg = true;
					ui.addNotification(null, E('p', _('Allowlist modifications have been saved, reload adblock that changes take effect.')), 'info');
				}
			}).catch(function (e) {
				resetScroll();
				ui.addNotification(null, E('p', _('Unable to save modifications: %s').format(e.message)), 'error');
			});
	},

	handleSaveApply: null,
	handleReset: null
});
